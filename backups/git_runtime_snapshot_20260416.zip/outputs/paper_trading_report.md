# Paper Trading Report

- generated_at: 2026-04-16 16:26:48
- history_snapshot_dir: D:\ai\Lee_trader\data\history\ranking
- price_source: D:\ai\Lee_trader\data\prices_daily_adjusted.csv
- hold_days: 20
- initial_nav_per_strategy: 1000000.00
- entry_fee_bps: 0.0
- exit_fee_bps: 0.0
- entry_slippage_bps: 0.0
- exit_slippage_bps: 0.0

## Trading Rules
- Each signal date reconstructs `buy_candidates_top5/top8/top10` from the stored ranking snapshot using the current operational buy-candidate rules.
- Each strategy deploys roughly `1/20` of current NAV into the day cohort and holds each position for 20 trading days.
- Duplicate entry rule: if a code is already open in the same strategy, the new signal is skipped until the existing position exits.
- Entry and exit are both modeled at daily close with optional fee/slippage adjustments.

## Strategy Summary
| strategy | final_nav  | cumulative_return | max_drawdown | closed_trades | win_rate | open_positions | duplicate_skips_total |
| -------- | ---------- | ----------------- | ------------ | ------------- | -------- | -------------- | --------------------- |
| top10    | 1036409.01 | 3.64%             | -2.07%       | 0             | NA       | 42             | 89                    |
| top5     | 1042294.75 | 4.23%             | -0.82%       | 0             | NA       | 26             | 57                    |
| top8     | 1042804.32 | 4.28%             | -1.77%       | 0             | NA       | 36             | 79                    |

## Signal Summary
| strategy | signal_dates | signal_count_total | opened_count_total | duplicate_skip_count_total |
| -------- | ------------ | ------------------ | ------------------ | -------------------------- |
| top10    | 23           | 131                | 42                 | 89                         |
| top5     | 23           | 83                 | 26                 | 57                         |
| top8     | 23           | 115                | 36                 | 79                         |

## Recent NAV
| strategy | date       | nav        | daily_return | cumulative_return | drawdown | active_position_count | opened_today | duplicate_skip_count |
| -------- | ---------- | ---------- | ------------ | ----------------- | -------- | --------------------- | ------------ | -------------------- |
| top10    | 2026-04-10 | 1007075.23 | 0.46%        | 0.71%             | 0.00%    | 32                    | 0            | 7                    |
| top10    | 2026-04-13 | 1005912.07 | -0.12%       | 0.59%             | -0.12%   | 33                    | 1            | 8                    |
| top10    | 2026-04-14 | 1014299.13 | 0.83%        | 1.43%             | 0.00%    | 35                    | 2            | 3                    |
| top10    | 2026-04-15 | 1031020.88 | 1.65%        | 3.10%             | 0.00%    | 39                    | 4            | 6                    |
| top10    | 2026-04-16 | 1036409.01 | 0.52%        | 3.64%             | 0.00%    | 42                    | 3            | 7                    |
| top5     | 2026-04-10 | 1025031.50 | 0.64%        | 2.50%             | 0.00%    | 22                    | 2            | 3                    |
| top5     | 2026-04-13 | 1023201.59 | -0.18%       | 2.32%             | -0.18%   | 23                    | 1            | 4                    |
| top5     | 2026-04-14 | 1029274.37 | 0.59%        | 2.93%             | 0.00%    | 25                    | 2            | 3                    |
| top5     | 2026-04-15 | 1039427.54 | 0.99%        | 3.94%             | 0.00%    | 26                    | 1            | 4                    |
| top5     | 2026-04-16 | 1042294.75 | 0.28%        | 4.23%             | 0.00%    | 26                    | 0            | 5                    |
| top8     | 2026-04-10 | 1013605.42 | 0.55%        | 1.36%             | 0.00%    | 29                    | 0            | 7                    |
| top8     | 2026-04-13 | 1012908.83 | -0.07%       | 1.29%             | -0.07%   | 30                    | 1            | 7                    |
| top8     | 2026-04-14 | 1021059.50 | 0.80%        | 2.11%             | 0.00%    | 32                    | 2            | 3                    |
| top8     | 2026-04-15 | 1038674.63 | 1.73%        | 3.87%             | 0.00%    | 34                    | 2            | 6                    |
| top8     | 2026-04-16 | 1042804.32 | 0.40%        | 4.28%             | 0.00%    | 36                    | 2            | 6                    |

## Open Positions
| strategy | code   | name        | entry_date | planned_exit_date | selection_stage    | gross_return |
| -------- | ------ | ----------- | ---------- | ----------------- | ------------------ | ------------ |
| top10    | 003490 | 대한항공        | 2026-03-20 |                   | strict             | -4.36%       |
| top10    | 011200 | HMM         | 2026-03-20 |                   | strict             | -0.24%       |
| top10    | 016360 | 삼성증권        | 2026-03-20 |                   | strict             | 8.11%        |
| top10    | 017670 | SK텔레콤       | 2026-03-20 |                   | strict             | 21.70%       |
| top10    | 030200 | KT          | 2026-03-20 |                   | strict             | 4.78%        |
| top10    | 032640 | LG유플러스      | 2026-03-20 |                   | strict             | 8.28%        |
| top10    | 085660 | 차바이오텍       | 2026-03-20 |                   | strict             | -4.59%       |
| top10    | 323410 | 카카오뱅크       | 2026-03-20 |                   | strict             | 2.19%        |
| top10    | 003550 | LG          | 2026-03-23 |                   | strict             | 8.06%        |
| top10    | 035720 | 카카오         | 2026-03-23 |                   | relax_no_theme_cap | 7.89%        |
| top10    | 058470 | 리노공업        | 2026-03-23 |                   | relax_no_theme_cap | 8.39%        |
| top10    | 138930 | BNK금융지주     | 2026-03-23 |                   | relax_no_theme_cap | 8.13%        |
| top10    | 259960 | 크래프톤        | 2026-03-23 |                   | strict             | 12.50%       |
| top10    | 278470 | 에이피알        | 2026-03-23 |                   | strict             | 27.73%       |
| top10    | 051910 | LG화학        | 2026-03-26 |                   | relax_no_theme_cap | 13.85%       |
| top10    | 145020 | 휴젤          | 2026-03-26 |                   | relax_no_theme_cap | 2.95%        |
| top10    | 041510 | 에스엠         | 2026-03-27 |                   | relax_no_theme_cap | 6.59%        |
| top10    | 352820 | 하이브         | 2026-03-31 |                   | relax_no_theme_cap | -10.37%      |
| top10    | 445680 | 큐리옥스바이오시스템즈 | 2026-03-31 |                   | relax_no_theme_cap | -10.55%      |
| top10    | 257720 | 실리콘투        | 2026-04-01 |                   | strict             | 17.25%       |
| top10    | 443060 | HD현대마린솔루션   | 2026-04-01 |                   | strict             | -3.09%       |
| top10    | 064400 | LG씨엔에스      | 2026-04-02 |                   | strict             | 18.76%       |
| top10    | 060370 | LS마린솔루션     | 2026-04-07 |                   | strict             | 11.57%       |
| top10    | 098460 | 고영          | 2026-04-07 |                   | strict             | 13.19%       |
| top10    | 267260 | HD현대일렉트릭    | 2026-04-07 |                   | strict             | 21.77%       |
| top10    | 403870 | HPSP        | 2026-04-07 |                   | strict             | 6.00%        |
| top10    | 015760 | 한국전력        | 2026-04-08 |                   | relax_no_theme_cap | 4.33%        |
| top10    | 033780 | KT&G        | 2026-04-08 |                   | strict             | 7.89%        |
| top10    | 042700 | 한미반도체       | 2026-04-08 |                   | strict             | 4.10%        |
| top10    | 326030 | SK바이오팜      | 2026-04-08 |                   | relax_no_theme_cap | 7.26%        |
| top10    | 035900 | JYP Ent.    | 2026-04-09 |                   | relax_no_theme_cap | 5.70%        |
| top10    | 039490 | 키움증권        | 2026-04-09 |                   | strict             | 2.80%        |
| top10    | 140860 | 파크시스템스      | 2026-04-13 |                   | relax_no_theme_cap | 0.39%        |
| top10    | 178320 | 서진시스템       | 2026-04-14 |                   | strict             | 0.50%        |
| top10    | 214150 | 클래시스        | 2026-04-14 |                   | strict             | 5.88%        |
| top10    | 028260 | 삼성물산        | 2026-04-15 |                   | relax_no_theme_cap | -0.49%       |
| top10    | 086450 | 동국제약        | 2026-04-15 |                   | relax_no_theme_cap | 0.00%        |
| top10    | 124500 | 아이티센글로벌     | 2026-04-15 |                   | strict             | -0.93%       |
| top10    | 237690 | 에스티팜        | 2026-04-15 |                   | relax_no_theme_cap | -0.54%       |
| top10    | 096530 | 씨젠          | 2026-04-16 |                   | relax_no_theme_cap | 0.00%        |
| top10    | 128940 | 한미약품        | 2026-04-16 |                   | relax_no_theme_cap | 0.00%        |
| top10    | 137400 | 피엔티         | 2026-04-16 |                   | relax_no_theme_cap | 0.00%        |
| top5     | 016360 | 삼성증권        | 2026-03-20 |                   | strict             | 8.11%        |
| top5     | 030200 | KT          | 2026-03-20 |                   | strict             | 4.78%        |
| top5     | 323410 | 카카오뱅크       | 2026-03-20 |                   | strict             | 2.19%        |
| top5     | 003550 | LG          | 2026-03-23 |                   | relax_no_theme_cap | 8.06%        |
| top5     | 011200 | HMM         | 2026-03-23 |                   | strict             | 7.02%        |
| top5     | 259960 | 크래프톤        | 2026-03-23 |                   | relax_no_theme_cap | 12.50%       |
| top5     | 278470 | 에이피알        | 2026-03-23 |                   | strict             | 27.73%       |
| top5     | 051910 | LG화학        | 2026-03-31 |                   | relax_no_theme_cap | 19.57%       |
| top5     | 138930 | BNK금융지주     | 2026-03-31 |                   | relax_no_theme_cap | 7.04%        |
| top5     | 257720 | 실리콘투        | 2026-04-01 |                   | relax_no_theme_cap | 17.25%       |
| top5     | 443060 | HD현대마린솔루션   | 2026-04-01 |                   | strict             | -3.09%       |
| top5     | 064400 | LG씨엔에스      | 2026-04-02 |                   | relax_no_theme_cap | 18.76%       |
| top5     | 060370 | LS마린솔루션     | 2026-04-07 |                   | strict             | 11.57%       |
| top5     | 098460 | 고영          | 2026-04-07 |                   | strict             | 13.19%       |
| top5     | 267260 | HD현대일렉트릭    | 2026-04-07 |                   | strict             | 21.77%       |
| top5     | 403870 | HPSP        | 2026-04-07 |                   | strict             | 6.00%        |
| top5     | 033780 | KT&G        | 2026-04-08 |                   | strict             | 7.89%        |
| top5     | 042700 | 한미반도체       | 2026-04-08 |                   | relax_no_theme_cap | 4.10%        |
| top5     | 145020 | 휴젤          | 2026-04-08 |                   | strict             | 5.43%        |
| top5     | 039490 | 키움증권        | 2026-04-09 |                   | relax_no_theme_cap | 2.80%        |
| top5     | 035900 | JYP Ent.    | 2026-04-10 |                   | relax_no_theme_cap | 4.65%        |
| top5     | 058470 | 리노공업        | 2026-04-10 |                   | strict             | 2.86%        |
| top5     | 032640 | LG유플러스      | 2026-04-13 |                   | strict             | -1.27%       |
| top5     | 178320 | 서진시스템       | 2026-04-14 |                   | relax_no_theme_cap | 0.50%        |
| top5     | 214150 | 클래시스        | 2026-04-14 |                   | strict             | 5.88%        |
| top5     | 124500 | 아이티센글로벌     | 2026-04-15 |                   | relax_no_theme_cap | -0.93%       |
| top8     | 011200 | HMM         | 2026-03-20 |                   | strict             | -0.24%       |
| top8     | 016360 | 삼성증권        | 2026-03-20 |                   | strict             | 8.11%        |
| top8     | 017670 | SK텔레콤       | 2026-03-20 |                   | strict             | 21.70%       |
| top8     | 030200 | KT          | 2026-03-20 |                   | strict             | 4.78%        |
| top8     | 032640 | LG유플러스      | 2026-03-20 |                   | strict             | 8.28%        |
| top8     | 323410 | 카카오뱅크       | 2026-03-20 |                   | strict             | 2.19%        |
| top8     | 003550 | LG          | 2026-03-23 |                   | strict             | 8.06%        |
| top8     | 035720 | 카카오         | 2026-03-23 |                   | relax_no_theme_cap | 7.89%        |
| top8     | 138930 | BNK금융지주     | 2026-03-23 |                   | relax_no_theme_cap | 8.13%        |
| top8     | 259960 | 크래프톤        | 2026-03-23 |                   | relax_no_theme_cap | 12.50%       |
| top8     | 278470 | 에이피알        | 2026-03-23 |                   | strict             | 27.73%       |
| top8     | 145020 | 휴젤          | 2026-03-26 |                   | relax_no_theme_cap | 2.95%        |
| top8     | 041510 | 에스엠         | 2026-03-27 |                   | relax_no_theme_cap | 6.59%        |
| top8     | 051910 | LG화학        | 2026-03-31 |                   | strict             | 19.57%       |
| top8     | 445680 | 큐리옥스바이오시스템즈 | 2026-03-31 |                   | relax_no_theme_cap | -10.55%      |
| top8     | 257720 | 실리콘투        | 2026-04-01 |                   | relax_no_theme_cap | 17.25%       |
| top8     | 443060 | HD현대마린솔루션   | 2026-04-01 |                   | strict             | -3.09%       |
| top8     | 064400 | LG씨엔에스      | 2026-04-02 |                   | relax_no_theme_cap | 18.76%       |
| top8     | 060370 | LS마린솔루션     | 2026-04-07 |                   | strict             | 11.57%       |
| top8     | 098460 | 고영          | 2026-04-07 |                   | strict             | 13.19%       |
| top8     | 267260 | HD현대일렉트릭    | 2026-04-07 |                   | strict             | 21.77%       |
| top8     | 403870 | HPSP        | 2026-04-07 |                   | strict             | 6.00%        |
| top8     | 015760 | 한국전력        | 2026-04-08 |                   | relax_no_theme_cap | 4.33%        |
| top8     | 033780 | KT&G        | 2026-04-08 |                   | strict             | 7.89%        |
| top8     | 042700 | 한미반도체       | 2026-04-08 |                   | strict             | 4.10%        |
| top8     | 058470 | 리노공업        | 2026-04-08 |                   | relax_no_theme_cap | -1.54%       |
| top8     | 035900 | JYP Ent.    | 2026-04-09 |                   | relax_no_theme_cap | 5.70%        |
| top8     | 039490 | 키움증권        | 2026-04-09 |                   | strict             | 2.80%        |
| top8     | 326030 | SK바이오팜      | 2026-04-09 |                   | relax_no_theme_cap | 9.02%        |
| top8     | 140860 | 파크시스템스      | 2026-04-13 |                   | relax_no_theme_cap | 0.39%        |
| top8     | 178320 | 서진시스템       | 2026-04-14 |                   | relax_no_theme_cap | 0.50%        |
| top8     | 214150 | 클래시스        | 2026-04-14 |                   | strict             | 5.88%        |
| top8     | 086450 | 동국제약        | 2026-04-15 |                   | relax_no_theme_cap | 0.00%        |
| top8     | 124500 | 아이티센글로벌     | 2026-04-15 |                   | strict             | -0.93%       |
| top8     | 096530 | 씨젠          | 2026-04-16 |                   | relax_no_theme_cap | 0.00%        |
| top8     | 128940 | 한미약품        | 2026-04-16 |                   | relax_no_theme_cap | 0.00%        |
