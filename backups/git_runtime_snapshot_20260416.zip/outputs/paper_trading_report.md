# Paper Trading Report

- generated_at: 2026-04-16 13:55:09
- history_snapshot_dir: D:\ai\Lee_trader\data\history\ranking
- price_source: D:\ai\Lee_trader\data\prices_daily_adjusted.csv
- hold_days: 20
- initial_nav_per_strategy: 1000000.00
- entry_fee_bps: 0.0
- exit_fee_bps: 0.0
- entry_slippage_bps: 0.0
- exit_slippage_bps: 0.0

## Trading Rules
- Each signal date reconstructs `buy_candidates_top5/top8/top10` from the stored ranking snapshot using the current operational buy-candidate rules.
- Each strategy deploys roughly `1/20` of current NAV into the day cohort and holds each position for 20 trading days.
- Duplicate entry rule: if a code is already open in the same strategy, the new signal is skipped until the existing position exits.
- Entry and exit are both modeled at daily close with optional fee/slippage adjustments.

## Strategy Summary
| strategy | final_nav  | cumulative_return | max_drawdown | closed_trades | win_rate | open_positions | duplicate_skips_total |
| -------- | ---------- | ----------------- | ------------ | ------------- | -------- | -------------- | --------------------- |
| top10    | 1031020.88 | 3.10%             | -2.07%       | 0             | NA       | 39             | 82                    |
| top5     | 1039427.54 | 3.94%             | -0.82%       | 0             | NA       | 26             | 52                    |
| top8     | 1038674.63 | 3.87%             | -1.77%       | 0             | NA       | 34             | 73                    |

## Signal Summary
| strategy | signal_dates | signal_count_total | opened_count_total | duplicate_skip_count_total |
| -------- | ------------ | ------------------ | ------------------ | -------------------------- |
| top10    | 22           | 121                | 39                 | 82                         |
| top5     | 22           | 78                 | 26                 | 52                         |
| top8     | 22           | 107                | 34                 | 73                         |

## Recent NAV
| strategy | date       | nav        | daily_return | cumulative_return | drawdown | active_position_count | opened_today | duplicate_skip_count |
| -------- | ---------- | ---------- | ------------ | ----------------- | -------- | --------------------- | ------------ | -------------------- |
| top10    | 2026-04-09 | 1002445.99 | 0.03%        | 0.24%             | 0.00%    | 32                    | 2            | 6                    |
| top10    | 2026-04-10 | 1007075.23 | 0.46%        | 0.71%             | 0.00%    | 32                    | 0            | 7                    |
| top10    | 2026-04-13 | 1005912.07 | -0.12%       | 0.59%             | -0.12%   | 33                    | 1            | 8                    |
| top10    | 2026-04-14 | 1014299.13 | 0.83%        | 1.43%             | 0.00%    | 35                    | 2            | 3                    |
| top10    | 2026-04-15 | 1031020.88 | 1.65%        | 3.10%             | 0.00%    | 39                    | 4            | 6                    |
| top5     | 2026-04-09 | 1018480.77 | 0.50%        | 1.85%             | 0.00%    | 20                    | 1            | 4                    |
| top5     | 2026-04-10 | 1025031.50 | 0.64%        | 2.50%             | 0.00%    | 22                    | 2            | 3                    |
| top5     | 2026-04-13 | 1023201.59 | -0.18%       | 2.32%             | -0.18%   | 23                    | 1            | 4                    |
| top5     | 2026-04-14 | 1029274.37 | 0.59%        | 2.93%             | 0.00%    | 25                    | 2            | 3                    |
| top5     | 2026-04-15 | 1039427.54 | 0.99%        | 3.94%             | 0.00%    | 26                    | 1            | 4                    |
| top8     | 2026-04-09 | 1008074.42 | 0.17%        | 0.81%             | 0.00%    | 29                    | 3            | 5                    |
| top8     | 2026-04-10 | 1013605.42 | 0.55%        | 1.36%             | 0.00%    | 29                    | 0            | 7                    |
| top8     | 2026-04-13 | 1012908.83 | -0.07%       | 1.29%             | -0.07%   | 30                    | 1            | 7                    |
| top8     | 2026-04-14 | 1021059.50 | 0.80%        | 2.11%             | 0.00%    | 32                    | 2            | 3                    |
| top8     | 2026-04-15 | 1038674.63 | 1.73%        | 3.87%             | 0.00%    | 34                    | 2            | 6                    |

## Open Positions
| strategy | code   | name        | entry_date | planned_exit_date | selection_stage    | gross_return |
| -------- | ------ | ----------- | ---------- | ----------------- | ------------------ | ------------ |
| top10    | 003490 | 대한항공        | 2026-03-20 |                   | strict             | -5.88%       |
| top10    | 011200 | HMM         | 2026-03-20 |                   | strict             | -0.71%       |
| top10    | 016360 | 삼성증권        | 2026-03-20 |                   | strict             | 8.60%        |
| top10    | 017670 | SK텔레콤       | 2026-03-20 |                   | strict             | 24.49%       |
| top10    | 030200 | KT          | 2026-03-20 |                   | strict             | 6.10%        |
| top10    | 032640 | LG유플러스      | 2026-03-20 |                   | strict             | 9.86%        |
| top10    | 085660 | 차바이오텍       | 2026-03-20 |                   | strict             | -4.38%       |
| top10    | 323410 | 카카오뱅크       | 2026-03-20 |                   | strict             | 1.59%        |
| top10    | 003550 | LG          | 2026-03-23 |                   | strict             | 7.49%        |
| top10    | 035720 | 카카오         | 2026-03-23 |                   | relax_no_theme_cap | 5.76%        |
| top10    | 058470 | 리노공업        | 2026-03-23 |                   | relax_no_theme_cap | 6.31%        |
| top10    | 138930 | BNK금융지주     | 2026-03-23 |                   | relax_no_theme_cap | 6.66%        |
| top10    | 259960 | 크래프톤        | 2026-03-23 |                   | strict             | 7.02%        |
| top10    | 278470 | 에이피알        | 2026-03-23 |                   | strict             | 27.27%       |
| top10    | 051910 | LG화학        | 2026-03-26 |                   | relax_no_theme_cap | 12.74%       |
| top10    | 145020 | 휴젤          | 2026-03-26 |                   | relax_no_theme_cap | 3.54%        |
| top10    | 041510 | 에스엠         | 2026-03-27 |                   | relax_no_theme_cap | -0.11%       |
| top10    | 352820 | 하이브         | 2026-03-31 |                   | relax_no_theme_cap | -14.55%      |
| top10    | 445680 | 큐리옥스바이오시스템즈 | 2026-03-31 |                   | relax_no_theme_cap | -8.09%       |
| top10    | 257720 | 실리콘투        | 2026-04-01 |                   | strict             | 17.00%       |
| top10    | 443060 | HD현대마린솔루션   | 2026-04-01 |                   | strict             | -1.71%       |
| top10    | 064400 | LG씨엔에스      | 2026-04-02 |                   | strict             | 16.28%       |
| top10    | 060370 | LS마린솔루션     | 2026-04-07 |                   | strict             | 9.33%        |
| top10    | 098460 | 고영          | 2026-04-07 |                   | strict             | 11.09%       |
| top10    | 267260 | HD현대일렉트릭    | 2026-04-07 |                   | strict             | 17.85%       |
| top10    | 403870 | HPSP        | 2026-04-07 |                   | strict             | 2.16%        |
| top10    | 015760 | 한국전력        | 2026-04-08 |                   | relax_no_theme_cap | 1.03%        |
| top10    | 033780 | KT&G        | 2026-04-08 |                   | strict             | 7.51%        |
| top10    | 042700 | 한미반도체       | 2026-04-08 |                   | strict             | 5.17%        |
| top10    | 326030 | SK바이오팜      | 2026-04-08 |                   | relax_no_theme_cap | 6.55%        |
| top10    | 035900 | JYP Ent.    | 2026-04-09 |                   | relax_no_theme_cap | 2.18%        |
| top10    | 039490 | 키움증권        | 2026-04-09 |                   | strict             | 4.25%        |
| top10    | 140860 | 파크시스템스      | 2026-04-13 |                   | relax_no_theme_cap | 4.89%        |
| top10    | 178320 | 서진시스템       | 2026-04-14 |                   | strict             | 2.70%        |
| top10    | 214150 | 클래시스        | 2026-04-14 |                   | strict             | 4.23%        |
| top10    | 028260 | 삼성물산        | 2026-04-15 |                   | relax_no_theme_cap | 0.00%        |
| top10    | 086450 | 동국제약        | 2026-04-15 |                   | relax_no_theme_cap | 0.00%        |
| top10    | 124500 | 아이티센글로벌     | 2026-04-15 |                   | strict             | 0.00%        |
| top10    | 237690 | 에스티팜        | 2026-04-15 |                   | relax_no_theme_cap | 0.00%        |
| top5     | 016360 | 삼성증권        | 2026-03-20 |                   | strict             | 8.60%        |
| top5     | 030200 | KT          | 2026-03-20 |                   | strict             | 6.10%        |
| top5     | 323410 | 카카오뱅크       | 2026-03-20 |                   | strict             | 1.59%        |
| top5     | 003550 | LG          | 2026-03-23 |                   | relax_no_theme_cap | 7.49%        |
| top5     | 011200 | HMM         | 2026-03-23 |                   | strict             | 6.51%        |
| top5     | 259960 | 크래프톤        | 2026-03-23 |                   | relax_no_theme_cap | 7.02%        |
| top5     | 278470 | 에이피알        | 2026-03-23 |                   | strict             | 27.27%       |
| top5     | 051910 | LG화학        | 2026-03-31 |                   | relax_no_theme_cap | 18.39%       |
| top5     | 138930 | BNK금융지주     | 2026-03-31 |                   | relax_no_theme_cap | 5.59%        |
| top5     | 257720 | 실리콘투        | 2026-04-01 |                   | relax_no_theme_cap | 17.00%       |
| top5     | 443060 | HD현대마린솔루션   | 2026-04-01 |                   | strict             | -1.71%       |
| top5     | 064400 | LG씨엔에스      | 2026-04-02 |                   | relax_no_theme_cap | 16.28%       |
| top5     | 060370 | LS마린솔루션     | 2026-04-07 |                   | strict             | 9.33%        |
| top5     | 098460 | 고영          | 2026-04-07 |                   | strict             | 11.09%       |
| top5     | 267260 | HD현대일렉트릭    | 2026-04-07 |                   | strict             | 17.85%       |
| top5     | 403870 | HPSP        | 2026-04-07 |                   | strict             | 2.16%        |
| top5     | 033780 | KT&G        | 2026-04-08 |                   | strict             | 7.51%        |
| top5     | 042700 | 한미반도체       | 2026-04-08 |                   | relax_no_theme_cap | 5.17%        |
| top5     | 145020 | 휴젤          | 2026-04-08 |                   | strict             | 6.04%        |
| top5     | 039490 | 키움증권        | 2026-04-09 |                   | relax_no_theme_cap | 4.25%        |
| top5     | 035900 | JYP Ent.    | 2026-04-10 |                   | relax_no_theme_cap | 1.16%        |
| top5     | 058470 | 리노공업        | 2026-04-10 |                   | strict             | 0.89%        |
| top5     | 032640 | LG유플러스      | 2026-04-13 |                   | strict             | 0.17%        |
| top5     | 178320 | 서진시스템       | 2026-04-14 |                   | relax_no_theme_cap | 2.70%        |
| top5     | 214150 | 클래시스        | 2026-04-14 |                   | strict             | 4.23%        |
| top5     | 124500 | 아이티센글로벌     | 2026-04-15 |                   | relax_no_theme_cap | 0.00%        |
| top8     | 011200 | HMM         | 2026-03-20 |                   | strict             | -0.71%       |
| top8     | 016360 | 삼성증권        | 2026-03-20 |                   | strict             | 8.60%        |
| top8     | 017670 | SK텔레콤       | 2026-03-20 |                   | strict             | 24.49%       |
| top8     | 030200 | KT          | 2026-03-20 |                   | strict             | 6.10%        |
| top8     | 032640 | LG유플러스      | 2026-03-20 |                   | strict             | 9.86%        |
| top8     | 323410 | 카카오뱅크       | 2026-03-20 |                   | strict             | 1.59%        |
| top8     | 003550 | LG          | 2026-03-23 |                   | strict             | 7.49%        |
| top8     | 035720 | 카카오         | 2026-03-23 |                   | relax_no_theme_cap | 5.76%        |
| top8     | 138930 | BNK금융지주     | 2026-03-23 |                   | relax_no_theme_cap | 6.66%        |
| top8     | 259960 | 크래프톤        | 2026-03-23 |                   | relax_no_theme_cap | 7.02%        |
| top8     | 278470 | 에이피알        | 2026-03-23 |                   | strict             | 27.27%       |
| top8     | 145020 | 휴젤          | 2026-03-26 |                   | relax_no_theme_cap | 3.54%        |
| top8     | 041510 | 에스엠         | 2026-03-27 |                   | relax_no_theme_cap | -0.11%       |
| top8     | 051910 | LG화학        | 2026-03-31 |                   | strict             | 18.39%       |
| top8     | 445680 | 큐리옥스바이오시스템즈 | 2026-03-31 |                   | relax_no_theme_cap | -8.09%       |
| top8     | 257720 | 실리콘투        | 2026-04-01 |                   | relax_no_theme_cap | 17.00%       |
| top8     | 443060 | HD현대마린솔루션   | 2026-04-01 |                   | strict             | -1.71%       |
| top8     | 064400 | LG씨엔에스      | 2026-04-02 |                   | relax_no_theme_cap | 16.28%       |
| top8     | 060370 | LS마린솔루션     | 2026-04-07 |                   | strict             | 9.33%        |
| top8     | 098460 | 고영          | 2026-04-07 |                   | strict             | 11.09%       |
| top8     | 267260 | HD현대일렉트릭    | 2026-04-07 |                   | strict             | 17.85%       |
| top8     | 403870 | HPSP        | 2026-04-07 |                   | strict             | 2.16%        |
| top8     | 015760 | 한국전력        | 2026-04-08 |                   | relax_no_theme_cap | 1.03%        |
| top8     | 033780 | KT&G        | 2026-04-08 |                   | strict             | 7.51%        |
| top8     | 042700 | 한미반도체       | 2026-04-08 |                   | strict             | 5.17%        |
| top8     | 058470 | 리노공업        | 2026-04-08 |                   | relax_no_theme_cap | -3.42%       |
| top8     | 035900 | JYP Ent.    | 2026-04-09 |                   | relax_no_theme_cap | 2.18%        |
| top8     | 039490 | 키움증권        | 2026-04-09 |                   | strict             | 4.25%        |
| top8     | 326030 | SK바이오팜      | 2026-04-09 |                   | relax_no_theme_cap | 8.30%        |
| top8     | 140860 | 파크시스템스      | 2026-04-13 |                   | relax_no_theme_cap | 4.89%        |
| top8     | 178320 | 서진시스템       | 2026-04-14 |                   | relax_no_theme_cap | 2.70%        |
| top8     | 214150 | 클래시스        | 2026-04-14 |                   | strict             | 4.23%        |
| top8     | 086450 | 동국제약        | 2026-04-15 |                   | relax_no_theme_cap | 0.00%        |
| top8     | 124500 | 아이티센글로벌     | 2026-04-15 |                   | strict             | 0.00%        |
