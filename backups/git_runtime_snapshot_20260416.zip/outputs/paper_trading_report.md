# Paper Trading Report

- generated_at: 2026-04-17 12:07:46
- history_snapshot_dir: D:\ai\Lee_trader\data\history\ranking
- price_source: D:\ai\Lee_trader\data\prices_daily_adjusted.csv
- hold_days: 20
- initial_nav_per_strategy: 1000000.00
- entry_fee_bps: 0.0
- exit_fee_bps: 0.0
- entry_slippage_bps: 0.0
- exit_slippage_bps: 0.0

## Trading Rules
- Each signal date reconstructs `buy_candidates_top5/top8/top10` from the stored ranking snapshot using the current operational buy-candidate rules.
- Each strategy deploys roughly `1/20` of current NAV into the day cohort and holds each position for 20 trading days.
- Duplicate entry rule: if a code is already open in the same strategy, the new signal is skipped until the existing position exits.
- Entry and exit are both modeled at daily close with optional fee/slippage adjustments.

## Strategy Summary
| strategy | final_nav  | cumulative_return | max_drawdown | closed_trades | win_rate | open_positions | duplicate_skips_total |
| -------- | ---------- | ----------------- | ------------ | ------------- | -------- | -------------- | --------------------- |
| top10    | 1007194.93 | 0.72%             | -1.82%       | 25            | 44.00%   | 23             | 83                    |
| top5     | 1020234.44 | 2.02%             | -0.71%       | 15            | 66.67%   | 12             | 56                    |
| top8     | 1011019.70 | 1.10%             | -1.76%       | 21            | 52.38%   | 18             | 76                    |

## Signal Summary
| strategy | signal_dates | signal_count_total | opened_count_total | duplicate_skip_count_total |
| -------- | ------------ | ------------------ | ------------------ | -------------------------- |
| top10    | 23           | 131                | 48                 | 83                         |
| top5     | 23           | 83                 | 27                 | 56                         |
| top8     | 23           | 115                | 39                 | 76                         |

## Recent NAV
| strategy | date       | nav        | daily_return | cumulative_return | drawdown | active_position_count | opened_today | duplicate_skip_count |
| -------- | ---------- | ---------- | ------------ | ----------------- | -------- | --------------------- | ------------ | -------------------- |
| top10    | 2026-04-10 | 998311.50  | 0.19%        | -0.17%            | -0.34%   | 12                    | 0            | 7                    |
| top10    | 2026-04-13 | 996907.36  | -0.14%       | -0.31%            | -0.48%   | 15                    | 3            | 6                    |
| top10    | 2026-04-14 | 999861.58  | 0.30%        | -0.01%            | -0.18%   | 16                    | 2            | 3                    |
| top10    | 2026-04-15 | 1006686.53 | 0.68%        | 0.67%             | 0.00%    | 20                    | 5            | 5                    |
| top10    | 2026-04-16 | 1007194.93 | 0.05%        | 0.72%             | 0.00%    | 23                    | 4            | 6                    |
| top5     | 2026-04-10 | 1012836.17 | 0.19%        | 1.28%             | 0.00%    | 10                    | 2            | 3                    |
| top5     | 2026-04-13 | 1012225.79 | -0.06%       | 1.22%             | -0.06%   | 11                    | 1            | 4                    |
| top5     | 2026-04-14 | 1016431.38 | 0.42%        | 1.64%             | 0.00%    | 12                    | 2            | 3                    |
| top5     | 2026-04-15 | 1020124.82 | 0.36%        | 2.01%             | 0.00%    | 13                    | 1            | 4                    |
| top5     | 2026-04-16 | 1020234.44 | 0.01%        | 2.02%             | 0.00%    | 12                    | 0            | 5                    |
| top8     | 2026-04-10 | 1001624.55 | 0.22%        | 0.16%             | -0.09%   | 12                    | 0            | 7                    |
| top8     | 2026-04-13 | 1000137.55 | -0.15%       | 0.01%             | -0.24%   | 14                    | 2            | 6                    |
| top8     | 2026-04-14 | 1003414.13 | 0.33%        | 0.34%             | 0.00%    | 15                    | 2            | 3                    |
| top8     | 2026-04-15 | 1011131.22 | 0.77%        | 1.11%             | 0.00%    | 17                    | 3            | 5                    |
| top8     | 2026-04-16 | 1011019.70 | -0.01%       | 1.10%             | -0.01%   | 18                    | 2            | 6                    |

## Exit Action Summary
| strategy | exit_action_code      | count |
| -------- | --------------------- | ----- |
| top10    | EXIT_SCORE_WEAK       | 14    |
| top10    | EXIT_STOP_LOSS        | 7     |
| top10    | EXIT_RANK_FADE        | 3     |
| top10    | EXIT_CONFIDENCE_BLOCK | 1     |
| top5     | EXIT_SCORE_WEAK       | 11    |
| top5     | EXIT_RANK_FADE        | 2     |
| top5     | EXIT_CONFIDENCE_BLOCK | 1     |
| top5     | EXIT_STOP_LOSS        | 1     |
| top8     | EXIT_SCORE_WEAK       | 14    |
| top8     | EXIT_RANK_FADE        | 3     |
| top8     | EXIT_STOP_LOSS        | 3     |
| top8     | EXIT_CONFIDENCE_BLOCK | 1     |

## Open Positions
| strategy | code   | name     | entry_date | planned_exit_date | current_action_code | selection_stage    | gross_return |
| -------- | ------ | -------- | ---------- | ----------------- | ------------------- | ------------------ | ------------ |
| top10    | 145020 | 휴젤       | 2026-03-26 |                   | HOLD_REVIEW_SOON    | relax_no_theme_cap | 2.95%        |
| top10    | 060370 | LS마린솔루션  | 2026-04-07 |                   | HOLD_ACTIVE         | strict             | 11.57%       |
| top10    | 098460 | 고영       | 2026-04-07 |                   | HOLD_ACTIVE         | strict             | 13.19%       |
| top10    | 403870 | HPSP     | 2026-04-07 |                   | HOLD_ACTIVE         | strict             | 6.00%        |
| top10    | 033780 | KT&G     | 2026-04-08 |                   | HOLD_ACTIVE         | strict             | 7.89%        |
| top10    | 042700 | 한미반도체    | 2026-04-08 |                   | HOLD_ACTIVE         | strict             | 4.10%        |
| top10    | 058470 | 리노공업     | 2026-04-08 |                   | HOLD_ACTIVE         | relax_no_theme_cap | -1.54%       |
| top10    | 326030 | SK바이오팜   | 2026-04-08 |                   | HOLD_ACTIVE         | relax_no_theme_cap | 7.26%        |
| top10    | 035900 | JYP Ent. | 2026-04-09 |                   | HOLD_ACTIVE         | relax_no_theme_cap | 5.70%        |
| top10    | 032640 | LG유플러스   | 2026-04-13 |                   | HOLD_ACTIVE         | strict             | -1.27%       |
| top10    | 140860 | 파크시스템스   | 2026-04-13 |                   | HOLD_ACTIVE         | relax_no_theme_cap | 0.39%        |
| top10    | 278470 | 에이피알     | 2026-04-13 |                   | HOLD_ACTIVE         | relax_no_theme_cap | 3.75%        |
| top10    | 178320 | 서진시스템    | 2026-04-14 |                   | HOLD_ACTIVE         | strict             | 0.50%        |
| top10    | 214150 | 클래시스     | 2026-04-14 |                   | HOLD_ACTIVE         | strict             | 5.88%        |
| top10    | 028260 | 삼성물산     | 2026-04-15 |                   | HOLD_NEW_ENTRY      | relax_no_theme_cap | -0.49%       |
| top10    | 035720 | 카카오      | 2026-04-15 |                   | HOLD_NEW_ENTRY      | relax_no_theme_cap | 2.02%        |
| top10    | 086450 | 동국제약     | 2026-04-15 |                   | HOLD_ACTIVE         | relax_no_theme_cap | 0.00%        |
| top10    | 124500 | 아이티센글로벌  | 2026-04-15 |                   | HOLD_NEW_ENTRY      | strict             | -0.93%       |
| top10    | 237690 | 에스티팜     | 2026-04-15 |                   | HOLD_NEW_ENTRY      | relax_no_theme_cap | -0.54%       |
| top10    | 096530 | 씨젠       | 2026-04-16 |                   | HOLD_NEW_ENTRY      | relax_no_theme_cap | 0.00%        |
| top10    | 128940 | 한미약품     | 2026-04-16 |                   | HOLD_NEW_ENTRY      | relax_no_theme_cap | 0.00%        |
| top10    | 137400 | 피엔티      | 2026-04-16 |                   | HOLD_NEW_ENTRY      | relax_no_theme_cap | 0.00%        |
| top10    | 138930 | BNK금융지주  | 2026-04-16 |                   | HOLD_NEW_ENTRY      | relax_no_theme_cap | 0.00%        |
| top5     | 060370 | LS마린솔루션  | 2026-04-07 |                   | HOLD_ACTIVE         | strict             | 11.57%       |
| top5     | 098460 | 고영       | 2026-04-07 |                   | HOLD_ACTIVE         | strict             | 13.19%       |
| top5     | 403870 | HPSP     | 2026-04-07 |                   | HOLD_ACTIVE         | strict             | 6.00%        |
| top5     | 033780 | KT&G     | 2026-04-08 |                   | HOLD_ACTIVE         | strict             | 7.89%        |
| top5     | 042700 | 한미반도체    | 2026-04-08 |                   | HOLD_ACTIVE         | relax_no_theme_cap | 4.10%        |
| top5     | 145020 | 휴젤       | 2026-04-08 |                   | HOLD_ACTIVE         | strict             | 5.43%        |
| top5     | 035900 | JYP Ent. | 2026-04-10 |                   | HOLD_ACTIVE         | relax_no_theme_cap | 4.65%        |
| top5     | 058470 | 리노공업     | 2026-04-10 |                   | HOLD_ACTIVE         | strict             | 2.86%        |
| top5     | 032640 | LG유플러스   | 2026-04-13 |                   | HOLD_ACTIVE         | strict             | -1.27%       |
| top5     | 178320 | 서진시스템    | 2026-04-14 |                   | HOLD_ACTIVE         | relax_no_theme_cap | 0.50%        |
| top5     | 214150 | 클래시스     | 2026-04-14 |                   | HOLD_ACTIVE         | strict             | 5.88%        |
| top5     | 124500 | 아이티센글로벌  | 2026-04-15 |                   | HOLD_NEW_ENTRY      | relax_no_theme_cap | -0.93%       |
| top8     | 145020 | 휴젤       | 2026-03-26 |                   | HOLD_REVIEW_SOON    | relax_no_theme_cap | 2.95%        |
| top8     | 060370 | LS마린솔루션  | 2026-04-07 |                   | HOLD_ACTIVE         | strict             | 11.57%       |
| top8     | 098460 | 고영       | 2026-04-07 |                   | HOLD_ACTIVE         | strict             | 13.19%       |
| top8     | 403870 | HPSP     | 2026-04-07 |                   | HOLD_ACTIVE         | strict             | 6.00%        |
| top8     | 033780 | KT&G     | 2026-04-08 |                   | HOLD_ACTIVE         | strict             | 7.89%        |
| top8     | 042700 | 한미반도체    | 2026-04-08 |                   | HOLD_ACTIVE         | strict             | 4.10%        |
| top8     | 058470 | 리노공업     | 2026-04-08 |                   | HOLD_ACTIVE         | relax_no_theme_cap | -1.54%       |
| top8     | 035900 | JYP Ent. | 2026-04-09 |                   | HOLD_ACTIVE         | relax_no_theme_cap | 5.70%        |
| top8     | 326030 | SK바이오팜   | 2026-04-09 |                   | HOLD_ACTIVE         | relax_no_theme_cap | 9.02%        |
| top8     | 032640 | LG유플러스   | 2026-04-13 |                   | HOLD_ACTIVE         | strict             | -1.27%       |
| top8     | 140860 | 파크시스템스   | 2026-04-13 |                   | HOLD_ACTIVE         | relax_no_theme_cap | 0.39%        |
| top8     | 178320 | 서진시스템    | 2026-04-14 |                   | HOLD_ACTIVE         | relax_no_theme_cap | 0.50%        |
| top8     | 214150 | 클래시스     | 2026-04-14 |                   | HOLD_ACTIVE         | strict             | 5.88%        |
| top8     | 035720 | 카카오      | 2026-04-15 |                   | HOLD_NEW_ENTRY      | relax_no_theme_cap | 2.02%        |
| top8     | 086450 | 동국제약     | 2026-04-15 |                   | HOLD_ACTIVE         | relax_no_theme_cap | 0.00%        |
| top8     | 124500 | 아이티센글로벌  | 2026-04-15 |                   | HOLD_NEW_ENTRY      | strict             | -0.93%       |
| top8     | 096530 | 씨젠       | 2026-04-16 |                   | HOLD_NEW_ENTRY      | relax_no_theme_cap | 0.00%        |
| top8     | 128940 | 한미약품     | 2026-04-16 |                   | HOLD_NEW_ENTRY      | relax_no_theme_cap | 0.00%        |
