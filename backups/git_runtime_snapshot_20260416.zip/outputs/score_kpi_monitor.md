# Score KPI Monitor

## KPI Guide
- GOOD: 현재 운영 신호가 기준 범위 안에 있습니다.
- WATCH: 추가 점검이 필요한 경계 구간입니다.
- ALERT: 즉시 원인 점검이 필요한 상태입니다.
- `overlap/corr` 계열은 최신 ranking slice 기준입니다.
- `walkforward_top20_avg_return_60d`는 matured walk-forward run 기준 60일 top20 평균 수익률입니다.
- `confidence_high_bucket_hit_rate_60d`는 현재 calibration에서 가장 높은 usable bucket의 hit rate입니다.
- `confidence_calibration_usable_bucket_count`는 현재 calibration에서 실제로 해석 가능한 bucket 수입니다.
- `confidence_calibration_source_mode`는 현재 confidence 해석 소스입니다.

## Metadata
- generated_at: 2026-04-16 13:54:51
- latest_date: 2026-04-15
- score_formula_version: ranking_builder_v8_return_prob_tech_regime
- source_ranking_file: ranking_final.csv; rows=206; modified_at=2026-04-16 13:53:25
- recomputed_from_current_code: true

## Overall Status
- overall_status: ALERT
- latest_date: 2026-04-15
- top_n: 20

## Thresholds
| metric | good_threshold | watch_threshold | direction |
| --- | --- | --- | --- |
| overlap_final_ret_top20 | 0.5000 | 0.4200 | higher_better |
| overlap_final_prob_top20 | 0.4500 | 0.3500 | higher_better |
| overlap_final_tech_top20 | 0.2500 | 0.1800 | higher_better |
| corr_final_risk_penalty_abs | 0.5000 | 0.6000 | lower_better |
| corr_final_safety_abs | 0.3000 | 0.4000 | lower_better |
| corr_final_ret_score | 0.8000 | 0.7000 | higher_better |
| corr_final_prob_score | 0.6500 | 0.5500 | higher_better |
| corr_final_tech_score | 0.1000 | 0.0300 | higher_better |
| top20_mean_confidence_score | 80.0000 | 72.0000 | higher_better |
| top20_top_driver_share | 0.3200 | 0.4000 | lower_better |
| walkforward_top20_avg_return_60d | 0.2000 | 0.0800 | higher_better |
| confidence_high_bucket_hit_rate_60d | 0.6000 | 0.5200 | higher_better |
| confidence_calibration_usable_bucket_count | 2.0000 | 1.0000 | higher_better |

## KPI Snapshot
| category | metric | value | good_threshold | watch_threshold | direction | status |
| --- | --- | --- | --- | --- | --- | --- |
| ranking | overlap_final_ret_top20 | 0.5500 | 0.5000 | 0.4200 | higher_better | GOOD |
| ranking | overlap_final_prob_top20 | 0.5500 | 0.4500 | 0.3500 | higher_better | GOOD |
| ranking | overlap_final_tech_top20 | 0.4000 | 0.2500 | 0.1800 | higher_better | GOOD |
| ranking | corr_final_risk_penalty_abs | 0.2810 | 0.5000 | 0.6000 | lower_better | GOOD |
| ranking | corr_final_safety_abs | 0.2030 | 0.3000 | 0.4000 | lower_better | GOOD |
| ranking | corr_final_ret_score | 0.8876 | 0.8000 | 0.7000 | higher_better | GOOD |
| ranking | corr_final_prob_score | 0.7957 | 0.6500 | 0.5500 | higher_better | GOOD |
| ranking | corr_final_tech_score | 0.1482 | 0.1000 | 0.0300 | higher_better | GOOD |
| ranking | top20_mean_confidence_score | 78.81 | 80.0000 | 72.0000 | higher_better | WATCH |
| ranking | top20_top_driver_share | 0.3333 | 0.3200 | 0.4000 | lower_better | WATCH |
| walkforward | walkforward_top20_avg_return_60d | NA | 0.2000 | 0.0800 | higher_better | ALERT |
| confidence | confidence_high_bucket_hit_rate_60d | NA | 0.6000 | 0.5200 | higher_better | ALERT |
| confidence | confidence_calibration_usable_bucket_count | 0.00 | 2.0000 | 1.0000 | higher_better | ALERT |
| confidence | confidence_calibration_source_mode | walkforward_provisional | - | - | informational | GOOD |

## Dominant Driver Frequency
| driver | count |
| --- | --- |
| high_ret_score | 20 |
| high_probability_score | 18 |
| high_tech_score | 8 |
| healthy_liquidity_profile | 5 |
| bull_regime_fit | 5 |
| strong_safety_profile | 3 |
| strong_quality_profile | 1 |

## Operator Notes
- `corr_final_safety_abs`와 driver frequency는 방어 편향 조기 탐지용입니다.
- `overlap_final_tech_top20`와 `corr_final_tech_score`는 tech 약화 탐지용입니다.
- `top20_mean_confidence_score`, `confidence_high_bucket_hit_rate_60d`, `confidence_calibration_usable_bucket_count`는 confidence 무력화 탐지용입니다.
- confidence source가 `walkforward_provisional`이면 정식 운영 calibration이 아니라 보조 해석 단계로 읽어야 합니다.
- daily pipeline 이후 `python python/score_kpi_monitor.py`만 실행하면 현재 상태를 다시 점검할 수 있습니다.
