# Theme Overlay Acceptance Report

## Snapshot
- latest_ranking_date: 2026-04-16
- ranking_final_source: data\ranking_final.csv
- overlay_score_source: data\ranking_final.csv (embedded final_score_v3)
- stock_theme_daily_latest_date: 2026-04-16
- row_count_latest: 206
- resolved_mode: off
- evaluation_profile: off_no_op
- overlay_score_column_used_for_evaluation: final_score
- shadow_score_source: data\ranking_final.csv (embedded shadow columns)
- mode_notice: mode=off, no effective overlay uplift expected.

## Final Decision
- decision: DO NOT PROMOTE
- metric_statuses: ['PASS', 'PASS', 'PASS', 'FAIL', 'WARN']

## 1. Top20 Churn Stability
- status: PASS
- intersection_ratio: 100.00%
- churn_ratio: 0.00%
- entered_count: 0
- exited_count: 0
- interpretation: overlap ratio is 100.00% and churn ratio is 0.00%.

## 2. No-Theme Retention
- status: PASS
- baseline_no_theme_top20_count: 6
- retained_count: 6
- retention_ratio: 100.00%
- interpretation: baseline top20 no-theme names retained at 100.00%.

## 3. Theme Concentration
- status: PASS
- max_theme: (none)
- max_share: 30.00%
- max_count: 6
- interpretation: the largest dominant theme share in overlay top20 is 30.00%.

## 4. Near-Top20 Entry Quality
- status: FAIL
- entry_count: 0
- explainable_count: 0
- explainable_ratio: 0.00%
- interpretation: explainable new entries account for 0.00%.

## 5. Theme Lift Effect
- status: WARN
- lifted_count: 0
- high_effective_count: 0
- high_effective_ratio: 0.00%
- high_effective_threshold: 0.0000
- interpretation: high theme-effective names among lifted stocks account for 0.00%.

## 6. Shadow Effect Diagnostics
- direct_uplift_count: 0
- direct_uplift_top20_count: 0
- indirect_rank_gain_count: 0
- large_negative_displacement_count: 0
- minimal_score_delta_threshold: 0.05
- large_negative_score_delta_threshold: -1.00
- interpretation: direct uplift means positive score delta with positive rank gain; indirect rank gain means rank gain with score delta near zero; large negative displacement tracks strong losers.

## 7. Explain Consistency
- sample_count: 20
- manual_review_count: 20
- interpretation: top overlay names are sampled for theme/explain consistency review.

## Review Pointers
- Check whether names with `(none)` dominant_theme still contain theme wording in explain_text.
- Check whether low-confidence new entries are being over-promoted.
- Check whether a single theme is dominating top20 beyond the intended cap.

## Output Files
- data\top20_churn_analysis.csv
- data\no_theme_retention.csv
- data\theme_concentration.csv
- data\theme_lift_analysis.csv
- data\new_entry_quality_report.csv
- data\theme_overlay_acceptance_mode_note.md

## Explain Sample
```json
[
  {
    "date":"2026-04-16",
    "code":"027360",
    "name":"아주IB투자",
    "overlay_rank":1,
    "dominant_theme":"(none)",
    "theme_confidence":0.0,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 79.6 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 37.9) | top_positive_factor=Primary prediction score (37.9) | top_negative_factor=Risk penalty (-7.2)\n핵심 driver: Primary prediction score (ret_score) contribution 37.9, score 99.9; Top-bucket probability score (prob_score) contribution 23.9, score 88.3; Tech flow score (tech_score) contribution 19.5, score 72.3\n리스크 요인: top_negative_factor=Risk penalty (-7.2); risk_penalty 18.0\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-16",
    "code":"007390",
    "name":"네이처셀",
    "overlay_rank":2,
    "dominant_theme":"바이오",
    "theme_confidence":0.4360720569,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 77.4 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 35.9) | top_positive_factor=Primary prediction score (35.9) | top_negative_factor=Risk penalty (-5.2)\n핵심 driver: Primary prediction score (ret_score) contribution 35.9, score 94.5; Top-bucket probability score (prob_score) contribution 25.8, score 95.6; Tech flow score (tech_score) contribution 20.1, score 74.5\n리스크 요인: top_negative_factor=Risk penalty (-5.2); risk_penalty 12.9\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-16",
    "code":"060370",
    "name":"LS마린솔루션",
    "overlay_rank":3,
    "dominant_theme":"전력설비",
    "theme_confidence":0.6271069343,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 76.1 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 35.4) | top_positive_factor=Primary prediction score (35.4) | top_negative_factor=Risk penalty (-4.2)\n핵심 driver: Primary prediction score (ret_score) contribution 35.4, score 93.3; Top-bucket probability score (prob_score) contribution 24.6, score 91.3; Tech flow score (tech_score) contribution 17.5, score 64.9\n리스크 요인: top_negative_factor=Risk penalty (-4.2); risk_penalty 10.6\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-16",
    "code":"089030",
    "name":"테크윙",
    "overlay_rank":4,
    "dominant_theme":"반도체장비",
    "theme_confidence":0.366825601,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 75.2 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 37.6) | top_positive_factor=Primary prediction score (37.6) | top_negative_factor=Risk penalty (-6.3)\n핵심 driver: Primary prediction score (ret_score) contribution 37.6, score 99.0; Top-bucket probability score (prob_score) contribution 24.1, score 89.3; Tech flow score (tech_score) contribution 18.8, score 69.8\n리스크 요인: top_negative_factor=Risk penalty (-6.3); risk_penalty 15.7\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-16",
    "code":"127120",
    "name":"제이에스링크",
    "overlay_rank":5,
    "dominant_theme":"(none)",
    "theme_confidence":0.0,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 74.3 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 36.3) | top_positive_factor=Primary prediction score (36.3) | top_negative_factor=Risk penalty (-7.2)\n핵심 driver: Primary prediction score (ret_score) contribution 36.3, score 95.4; Top-bucket probability score (prob_score) contribution 26.1, score 96.6; Tech flow score (tech_score) contribution 18.9, score 70.1\n리스크 요인: top_negative_factor=Risk penalty (-7.2); risk_penalty 18.0\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-16",
    "code":"336370",
    "name":"솔루스첨단소재",
    "overlay_rank":6,
    "dominant_theme":"2차전지",
    "theme_confidence":0.4072699818,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 73.0 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 33.8) | top_positive_factor=Primary prediction score (33.8) | top_negative_factor=Risk penalty (-7.2)\n핵심 driver: Primary prediction score (ret_score) contribution 33.8, score 89.1; Top-bucket probability score (prob_score) contribution 25.2, score 93.2; Tech flow score (tech_score) contribution 20.3, score 75.1\n리스크 요인: top_negative_factor=Risk penalty (-7.2); risk_penalty 18.0\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-16",
    "code":"124500",
    "name":null,
    "overlay_rank":7,
    "dominant_theme":"(none)",
    "theme_confidence":0.0,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 72.0 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 36.4) | top_positive_factor=Primary prediction score (36.4) | top_negative_factor=Risk penalty (-7.1)\n핵심 driver: Primary prediction score (ret_score) contribution 36.4, score 95.8; Top-bucket probability score (prob_score) contribution 25.0, score 92.7; Tech flow score (tech_score) contribution 12.0, score 44.4\n리스크 요인: top_negative_factor=Risk penalty (-7.1); risk_penalty 17.7\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-16",
    "code":"001440",
    "name":"대한전선",
    "overlay_rank":8,
    "dominant_theme":"(none)",
    "theme_confidence":0.0,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 70.9 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 34.9) | top_positive_factor=Primary prediction score (34.9) | top_negative_factor=Risk penalty (-7.2)\n핵심 driver: Primary prediction score (ret_score) contribution 34.9, score 91.9; Tech flow score (tech_score) contribution 21.5, score 79.7; Top-bucket probability score (prob_score) contribution 20.2, score 74.8\n리스크 요인: top_negative_factor=Risk penalty (-7.2); risk_penalty 18.0\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-16",
    "code":"041510",
    "name":"에스엠",
    "overlay_rank":9,
    "dominant_theme":"(none)",
    "theme_confidence":0.0,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 70.5 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 32.5) | top_positive_factor=Primary prediction score (32.5) | top_negative_factor=Risk penalty (-2.1)\n핵심 driver: Primary prediction score (ret_score) contribution 32.5, score 85.6; Top-bucket probability score (prob_score) contribution 20.7, score 76.7; Tech flow score (tech_score) contribution 13.0, score 48.0\n리스크 요인: top_negative_factor=Risk penalty (-2.1); risk_penalty 5.2\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-16",
    "code":"214150",
    "name":"클래시스",
    "overlay_rank":10,
    "dominant_theme":"바이오",
    "theme_confidence":0.3410720569,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 69.9 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 27.9) | top_positive_factor=Primary prediction score (27.9) | top_negative_factor=Risk penalty (-6.1)\n핵심 driver: Primary prediction score (ret_score) contribution 27.9, score 73.3; Top-bucket probability score (prob_score) contribution 22.3, score 82.5; Tech flow score (tech_score) contribution 18.2, score 67.3\n리스크 요인: top_negative_factor=Risk penalty (-6.1); risk_penalty 15.3\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-16",
    "code":"032640",
    "name":"LG유플러스",
    "overlay_rank":11,
    "dominant_theme":"Digital Connectivity",
    "theme_confidence":0.6873454035,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 69.8 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 32.9) | top_positive_factor=Primary prediction score (32.9) | top_negative_factor=Risk penalty (-2.7)\n핵심 driver: Primary prediction score (ret_score) contribution 32.9, score 86.7; Top-bucket probability score (prob_score) contribution 18.3, score 68.0; Tech flow score (tech_score) contribution 18.0, score 66.8\n리스크 요인: top_negative_factor=Risk penalty (-2.7); risk_penalty 6.7\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-16",
    "code":"281740",
    "name":"레이크머티리얼즈",
    "overlay_rank":12,
    "dominant_theme":"2차전지",
    "theme_confidence":0.3747699818,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 69.3 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 33.4) | top_positive_factor=Primary prediction score (33.4) | top_negative_factor=Risk penalty (-7.2)\n핵심 driver: Primary prediction score (ret_score) contribution 33.4, score 87.9; Top-bucket probability score (prob_score) contribution 24.0, score 88.8; Tech flow score (tech_score) contribution 17.5, score 64.8\n리스크 요인: top_negative_factor=Risk penalty (-7.2); risk_penalty 18.0\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-16",
    "code":"005940",
    "name":"NH투자증권",
    "overlay_rank":13,
    "dominant_theme":"Brokerage Markets",
    "theme_confidence":0.6648412832,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 69.3 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 33.8) | top_positive_factor=Primary prediction score (33.8) | top_negative_factor=Risk penalty (-7.2)\n핵심 driver: Primary prediction score (ret_score) contribution 33.8, score 88.8; Top-bucket probability score (prob_score) contribution 24.4, score 90.3; Tech flow score (tech_score) contribution 17.1, score 63.4\n리스크 요인: top_negative_factor=Risk penalty (-7.2); risk_penalty 18.0\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-16",
    "code":"096530",
    "name":"씨젠",
    "overlay_rank":14,
    "dominant_theme":"바이오",
    "theme_confidence":0.4235720569,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 68.8 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 30.7) | top_positive_factor=Primary prediction score (30.7) | top_negative_factor=Risk penalty (-4.9)\n핵심 driver: Primary prediction score (ret_score) contribution 30.7, score 80.7; Top-bucket probability score (prob_score) contribution 23.7, score 87.9; Tech flow score (tech_score) contribution 16.8, score 62.2\n리스크 요인: top_negative_factor=Risk penalty (-4.9); risk_penalty 12.3\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-16",
    "code":"035720",
    "name":"카카오",
    "overlay_rank":15,
    "dominant_theme":"Digital Platform Ecosystem",
    "theme_confidence":0.6719303557,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 68.5 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 26.9) | top_positive_factor=Primary prediction score (26.9) | top_negative_factor=Risk penalty (-4.4)\n핵심 driver: Primary prediction score (ret_score) contribution 26.9, score 70.7; Top-bucket probability score (prob_score) contribution 24.5, score 90.8; Tech flow score (tech_score) contribution 17.8, score 66.1\n리스크 요인: top_negative_factor=Risk penalty (-4.4); risk_penalty 10.9\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-16",
    "code":"0126Z0",
    "name":"삼성에피스홀딩스",
    "overlay_rank":16,
    "dominant_theme":"바이오",
    "theme_confidence":0.4360720569,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 68.5 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 36.3) | top_positive_factor=Primary prediction score (36.3) | top_negative_factor=Risk penalty (-3.3)\n핵심 driver: Primary prediction score (ret_score) contribution 36.3, score 95.4; Top-bucket probability score (prob_score) contribution 21.8, score 80.6; Tech flow score (tech_score) contribution 13.7, score 50.8\n리스크 요인: top_negative_factor=Risk penalty (-3.3); risk_penalty 8.2\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-16",
    "code":"445680",
    "name":"큐리옥스바이오시스템즈",
    "overlay_rank":17,
    "dominant_theme":"바이오",
    "theme_confidence":0.4235720569,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 68.3 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 37.2) | top_positive_factor=Primary prediction score (37.2) | top_negative_factor=Risk penalty (-2.7)\n핵심 driver: Primary prediction score (ret_score) contribution 37.2, score 98.0; Top-bucket probability score (prob_score) contribution 26.3, score 97.6; Tech flow score (tech_score) contribution 7.3, score 26.9\n리스크 요인: top_negative_factor=Risk penalty (-2.7); risk_penalty 6.8\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-16",
    "code":"377300",
    "name":"카카오페이",
    "overlay_rank":18,
    "dominant_theme":"Digital Finance Platform",
    "theme_confidence":0.6759887609,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 68.3 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 35.2) | top_positive_factor=Primary prediction score (35.2) | top_negative_factor=Risk penalty (-7.2)\n핵심 driver: Primary prediction score (ret_score) contribution 35.2, score 92.6; Top-bucket probability score (prob_score) contribution 24.9, score 92.2; Tech flow score (tech_score) contribution 13.7, score 50.6\n리스크 요인: top_negative_factor=Risk penalty (-7.2); risk_penalty 18.0\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-16",
    "code":"178320",
    "name":"서진시스템",
    "overlay_rank":19,
    "dominant_theme":"AI서버기판",
    "theme_confidence":0.6520510949,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 68.0 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 29.0) | top_positive_factor=Primary prediction score (29.0) | top_negative_factor=Risk penalty (-7.2)\n핵심 driver: Primary prediction score (ret_score) contribution 29.0, score 76.3; Top-bucket probability score (prob_score) contribution 25.7, score 95.1; Tech flow score (tech_score) contribution 18.8, score 69.7\n리스크 요인: top_negative_factor=Risk penalty (-7.2); risk_penalty 18.0\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-16",
    "code":"417200",
    "name":"LS머트리얼즈",
    "overlay_rank":20,
    "dominant_theme":"(none)",
    "theme_confidence":0.0,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 68.0 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 35.3) | top_positive_factor=Primary prediction score (35.3) | top_negative_factor=Risk penalty (-7.2)\n핵심 driver: Primary prediction score (ret_score) contribution 35.3, score 92.9; Top-bucket probability score (prob_score) contribution 21.4, score 79.1; Tech flow score (tech_score) contribution 16.6, score 61.6\n리스크 요인: top_negative_factor=Risk penalty (-7.2); risk_penalty 18.0\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  }
]
```
