# Theme Overlay Acceptance Report

## Snapshot
- latest_ranking_date: 2026-04-16
- ranking_final_source: data\ranking_final.csv
- overlay_score_source: data\ranking_final.csv (embedded final_score_v3)
- stock_theme_daily_latest_date: 2026-04-16
- row_count_latest: 204
- resolved_mode: off
- evaluation_profile: off_no_op
- overlay_score_column_used_for_evaluation: final_score
- shadow_score_source: data\ranking_final.csv (embedded shadow columns)
- mode_notice: mode=off, no effective overlay uplift expected.

## Final Decision
- decision: DO NOT PROMOTE
- metric_statuses: ['PASS', 'PASS', 'PASS', 'FAIL', 'WARN']

## 1. Top20 Churn Stability
- status: PASS
- intersection_ratio: 100.00%
- churn_ratio: 0.00%
- entered_count: 0
- exited_count: 0
- interpretation: overlap ratio is 100.00% and churn ratio is 0.00%.

## 2. No-Theme Retention
- status: PASS
- baseline_no_theme_top20_count: 5
- retained_count: 5
- retention_ratio: 100.00%
- interpretation: baseline top20 no-theme names retained at 100.00%.

## 3. Theme Concentration
- status: PASS
- max_theme: (none)
- max_share: 25.00%
- max_count: 5
- interpretation: the largest dominant theme share in overlay top20 is 25.00%.

## 4. Near-Top20 Entry Quality
- status: FAIL
- entry_count: 0
- explainable_count: 0
- explainable_ratio: 0.00%
- interpretation: explainable new entries account for 0.00%.

## 5. Theme Lift Effect
- status: WARN
- lifted_count: 0
- high_effective_count: 0
- high_effective_ratio: 0.00%
- high_effective_threshold: 0.0000
- interpretation: high theme-effective names among lifted stocks account for 0.00%.

## 6. Shadow Effect Diagnostics
- direct_uplift_count: 0
- direct_uplift_top20_count: 0
- indirect_rank_gain_count: 0
- large_negative_displacement_count: 0
- minimal_score_delta_threshold: 0.05
- large_negative_score_delta_threshold: -1.00
- interpretation: direct uplift means positive score delta with positive rank gain; indirect rank gain means rank gain with score delta near zero; large negative displacement tracks strong losers.

## 7. Explain Consistency
- sample_count: 20
- manual_review_count: 20
- interpretation: top overlay names are sampled for theme/explain consistency review.

## Review Pointers
- Check whether names with `(none)` dominant_theme still contain theme wording in explain_text.
- Check whether low-confidence new entries are being over-promoted.
- Check whether a single theme is dominating top20 beyond the intended cap.

## Output Files
- data\top20_churn_analysis.csv
- data\no_theme_retention.csv
- data\theme_concentration.csv
- data\theme_lift_analysis.csv
- data\new_entry_quality_report.csv
- data\theme_overlay_acceptance_mode_note.md

## Explain Sample
```json
[
  {
    "date":"2026-04-16",
    "code":"027360",
    "name":"아주IB투자",
    "overlay_rank":1,
    "dominant_theme":"(none)",
    "theme_confidence":0.0,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 80.9 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 37.8) | top_positive_factor=Primary prediction score (37.8) | top_negative_factor=Risk penalty (-7.2)\n핵심 driver: Primary prediction score (ret_score) contribution 37.8, score 99.4; Top-bucket probability score (prob_score) contribution 25.3, score 93.6; Tech flow score (tech_score) contribution 19.5, score 72.4\n리스크 요인: top_negative_factor=Risk penalty (-7.2); risk_penalty 18.0\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-16",
    "code":"001440",
    "name":"대한전선",
    "overlay_rank":2,
    "dominant_theme":"(none)",
    "theme_confidence":0.0,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 76.5 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 35.8) | top_positive_factor=Primary prediction score (35.8) | top_negative_factor=Risk penalty (-7.0)\n핵심 driver: Primary prediction score (ret_score) contribution 35.8, score 94.3; Top-bucket probability score (prob_score) contribution 24.8, score 91.7; Tech flow score (tech_score) contribution 21.5, score 79.7\n리스크 요인: top_negative_factor=Risk penalty (-7.0); risk_penalty 17.6\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-16",
    "code":"007390",
    "name":"네이처셀",
    "overlay_rank":3,
    "dominant_theme":"바이오",
    "theme_confidence":0.4361703894,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 76.0 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 34.7) | top_positive_factor=Primary prediction score (34.7) | top_negative_factor=Risk penalty (-5.4)\n핵심 driver: Primary prediction score (ret_score) contribution 34.7, score 91.3; Top-bucket probability score (prob_score) contribution 25.8, score 95.6; Tech flow score (tech_score) contribution 20.2, score 74.8\n리스크 요인: top_negative_factor=Risk penalty (-5.4); risk_penalty 13.4\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-16",
    "code":"336370",
    "name":"솔루스첨단소재",
    "overlay_rank":4,
    "dominant_theme":"2차전지",
    "theme_confidence":0.4077019385,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 75.5 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 35.1) | top_positive_factor=Primary prediction score (35.1) | top_negative_factor=Risk penalty (-7.2)\n핵심 driver: Primary prediction score (ret_score) contribution 35.1, score 92.5; Top-bucket probability score (prob_score) contribution 26.3, score 97.5; Tech flow score (tech_score) contribution 20.3, score 75.3\n리스크 요인: top_negative_factor=Risk penalty (-7.2); risk_penalty 18.0\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-16",
    "code":"127120",
    "name":"제이에스링크",
    "overlay_rank":5,
    "dominant_theme":"(none)",
    "theme_confidence":0.0,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 74.5 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 36.8) | top_positive_factor=Primary prediction score (36.8) | top_negative_factor=Risk penalty (-7.2)\n핵심 driver: Primary prediction score (ret_score) contribution 36.8, score 96.9; Top-bucket probability score (prob_score) contribution 25.7, score 95.1; Tech flow score (tech_score) contribution 19.0, score 70.4\n리스크 요인: top_negative_factor=Risk penalty (-7.2); risk_penalty 18.0\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-16",
    "code":"089030",
    "name":"테크윙",
    "overlay_rank":6,
    "dominant_theme":"반도체장비",
    "theme_confidence":0.3659912664,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 72.4 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 37.0) | top_positive_factor=Primary prediction score (37.0) | top_negative_factor=Risk penalty (-7.2)\n핵심 driver: Primary prediction score (ret_score) contribution 37.0, score 97.4; Top-bucket probability score (prob_score) contribution 22.8, score 84.3; Tech flow score (tech_score) contribution 18.9, score 69.9\n리스크 요인: top_negative_factor=Risk penalty (-7.2); risk_penalty 18.0\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-16",
    "code":"178320",
    "name":"서진시스템",
    "overlay_rank":7,
    "dominant_theme":"AI서버기판",
    "theme_confidence":0.6521776874,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 71.9 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 34.4) | top_positive_factor=Primary prediction score (34.4) | top_negative_factor=Risk penalty (-7.2)\n핵심 driver: Primary prediction score (ret_score) contribution 34.4, score 90.6; Top-bucket probability score (prob_score) contribution 24.1, score 89.2; Tech flow score (tech_score) contribution 18.9, score 69.9\n리스크 요인: top_negative_factor=Risk penalty (-7.2); risk_penalty 18.0\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-16",
    "code":"035900",
    "name":"JYP Ent.",
    "overlay_rank":8,
    "dominant_theme":"(none)",
    "theme_confidence":0.0,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 71.8 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 30.1) | top_positive_factor=Primary prediction score (30.1) | top_negative_factor=Risk penalty (-4.2)\n핵심 driver: Primary prediction score (ret_score) contribution 30.1, score 79.1; Top-bucket probability score (prob_score) contribution 26.9, score 99.5; Tech flow score (tech_score) contribution 12.2, score 45.1\n리스크 요인: top_negative_factor=Risk penalty (-4.2); risk_penalty 10.4\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-16",
    "code":"060370",
    "name":"LS마린솔루션",
    "overlay_rank":9,
    "dominant_theme":"전력설비",
    "theme_confidence":0.6268052358,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 71.6 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 33.2) | top_positive_factor=Primary prediction score (33.2) | top_negative_factor=Risk penalty (-6.9)\n핵심 driver: Primary prediction score (ret_score) contribution 33.2, score 87.5; Top-bucket probability score (prob_score) contribution 24.9, score 92.2; Tech flow score (tech_score) contribution 17.6, score 65.1\n리스크 요인: top_negative_factor=Risk penalty (-6.9); risk_penalty 17.2\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-16",
    "code":"214150",
    "name":"클래시스",
    "overlay_rank":10,
    "dominant_theme":"바이오",
    "theme_confidence":0.3411703894,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 71.4 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 29.2) | top_positive_factor=Primary prediction score (29.2) | top_negative_factor=Risk penalty (-5.5)\n핵심 driver: Primary prediction score (ret_score) contribution 29.2, score 76.7; Top-bucket probability score (prob_score) contribution 21.8, score 80.9; Tech flow score (tech_score) contribution 18.2, score 67.5\n리스크 요인: top_negative_factor=Risk penalty (-5.5); risk_penalty 13.8\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-16",
    "code":"281740",
    "name":"레이크머티리얼즈",
    "overlay_rank":11,
    "dominant_theme":"2차전지",
    "theme_confidence":0.3752019385,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 71.4 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 34.4) | top_positive_factor=Primary prediction score (34.4) | top_negative_factor=Risk penalty (-6.9)\n핵심 driver: Primary prediction score (ret_score) contribution 34.4, score 90.6; Top-bucket probability score (prob_score) contribution 24.6, score 91.2; Tech flow score (tech_score) contribution 17.6, score 65.1\n리스크 요인: top_negative_factor=Risk penalty (-6.9); risk_penalty 17.2\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-16",
    "code":"0126Z0",
    "name":"삼성에피스홀딩스",
    "overlay_rank":12,
    "dominant_theme":"바이오",
    "theme_confidence":0.4361703894,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 70.7 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 35.5) | top_positive_factor=Primary prediction score (35.5) | top_negative_factor=Risk penalty (-3.5)\n핵심 driver: Primary prediction score (ret_score) contribution 35.5, score 93.4; Top-bucket probability score (prob_score) contribution 25.0, score 92.6; Tech flow score (tech_score) contribution 13.7, score 50.9\n리스크 요인: top_negative_factor=Risk penalty (-3.5); risk_penalty 8.8\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-16",
    "code":"005940",
    "name":"NH투자증권",
    "overlay_rank":13,
    "dominant_theme":"Brokerage Markets",
    "theme_confidence":0.6650894897,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 70.7 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 35.0) | top_positive_factor=Primary prediction score (35.0) | top_negative_factor=Risk penalty (-7.0)\n핵심 driver: Primary prediction score (ret_score) contribution 35.0, score 92.1; Top-bucket probability score (prob_score) contribution 24.4, score 90.2; Tech flow score (tech_score) contribution 17.1, score 63.5\n리스크 요인: top_negative_factor=Risk penalty (-7.0); risk_penalty 17.6\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-16",
    "code":"145020",
    "name":"휴젤",
    "overlay_rank":14,
    "dominant_theme":"바이오",
    "theme_confidence":0.4061703894,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 70.7 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 33.9) | top_positive_factor=Primary prediction score (33.9) | top_negative_factor=Risk penalty (-4.0)\n핵심 driver: Primary prediction score (ret_score) contribution 33.9, score 89.3; Top-bucket probability score (prob_score) contribution 23.4, score 86.8; Tech flow score (tech_score) contribution 9.6, score 35.4\n리스크 요인: top_negative_factor=Risk penalty (-4.0); risk_penalty 10.0\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-16",
    "code":"017670",
    "name":"SK텔레콤",
    "overlay_rank":15,
    "dominant_theme":"Digital Connectivity",
    "theme_confidence":0.6959045717,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 69.7 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 32.2) | top_positive_factor=Primary prediction score (32.2) | top_negative_factor=Risk penalty (-7.0)\n핵심 driver: Primary prediction score (ret_score) contribution 32.2, score 84.8; Top-bucket probability score (prob_score) contribution 22.1, score 81.9; Tech flow score (tech_score) contribution 20.9, score 77.6\n리스크 요인: top_negative_factor=Risk penalty (-7.0); risk_penalty 17.4\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-16",
    "code":"316140",
    "name":"우리금융지주",
    "overlay_rank":16,
    "dominant_theme":"Retail Finance Return",
    "theme_confidence":0.4243591664,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 69.4 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 31.9) | top_positive_factor=Primary prediction score (31.9) | top_negative_factor=Risk penalty (-2.9)\n핵심 driver: Primary prediction score (ret_score) contribution 31.9, score 84.0; Top-bucket probability score (prob_score) contribution 20.9, score 77.5; Tech flow score (tech_score) contribution 18.8, score 69.7\n리스크 요인: top_negative_factor=Risk penalty (-2.9); risk_penalty 7.3\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-16",
    "code":"032640",
    "name":"LG유플러스",
    "overlay_rank":17,
    "dominant_theme":"Digital Connectivity",
    "theme_confidence":0.6859045717,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 69.3 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 30.0) | top_positive_factor=Primary prediction score (30.0) | top_negative_factor=Risk penalty (-2.4)\n핵심 driver: Primary prediction score (ret_score) contribution 30.0, score 79.1; Top-bucket probability score (prob_score) contribution 20.4, score 75.5; Tech flow score (tech_score) contribution 18.1, score 67.0\n리스크 요인: top_negative_factor=Risk penalty (-2.4); risk_penalty 6.0\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-16",
    "code":"397030",
    "name":"에이프릴바이오",
    "overlay_rank":18,
    "dominant_theme":"(none)",
    "theme_confidence":0.0,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 69.2 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 36.2) | top_positive_factor=Primary prediction score (36.2) | top_negative_factor=Risk penalty (-7.2)\n핵심 driver: Primary prediction score (ret_score) contribution 36.2, score 95.2; Top-bucket probability score (prob_score) contribution 25.4, score 94.1; Tech flow score (tech_score) contribution 14.0, score 51.7\n리스크 요인: top_negative_factor=Risk penalty (-7.2); risk_penalty 18.0\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-16",
    "code":"085660",
    "name":"차바이오텍",
    "overlay_rank":19,
    "dominant_theme":"바이오",
    "theme_confidence":0.4611703894,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 68.3 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 37.7) | top_positive_factor=Primary prediction score (37.7) | top_negative_factor=Risk penalty (-6.1)\n핵심 driver: Primary prediction score (ret_score) contribution 37.7, score 99.3; Top-bucket probability score (prob_score) contribution 27.0, score 100.0; Tech flow score (tech_score) contribution 9.0, score 33.3\n리스크 요인: top_negative_factor=Risk penalty (-6.1); risk_penalty 15.2\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-16",
    "code":"403870",
    "name":"HPSP",
    "overlay_rank":20,
    "dominant_theme":"반도체장비",
    "theme_confidence":0.4459912664,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 68.2 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 30.7) | top_positive_factor=Primary prediction score (30.7) | top_negative_factor=Risk penalty (-5.0)\n핵심 driver: Primary prediction score (ret_score) contribution 30.7, score 80.8; Top-bucket probability score (prob_score) contribution 24.5, score 90.7; Tech flow score (tech_score) contribution 10.1, score 37.4\n리스크 요인: top_negative_factor=Risk penalty (-5.0); risk_penalty 12.4\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  }
]
```
