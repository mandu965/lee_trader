# Theme Overlay Acceptance Report

## Snapshot
- latest_ranking_date: 2026-04-15
- ranking_final_source: data\ranking_final.csv
- overlay_score_source: data\ranking_final.csv (embedded final_score_v3)
- stock_theme_daily_latest_date: 2026-04-15
- row_count_latest: 206
- resolved_mode: off
- evaluation_profile: off_no_op
- overlay_score_column_used_for_evaluation: final_score
- shadow_score_source: data\ranking_final.csv (embedded shadow columns)
- mode_notice: mode=off, no effective overlay uplift expected.

## Final Decision
- decision: DO NOT PROMOTE
- metric_statuses: ['PASS', 'PASS', 'PASS', 'FAIL', 'WARN']

## 1. Top20 Churn Stability
- status: PASS
- intersection_ratio: 100.00%
- churn_ratio: 0.00%
- entered_count: 0
- exited_count: 0
- interpretation: overlap ratio is 100.00% and churn ratio is 0.00%.

## 2. No-Theme Retention
- status: PASS
- baseline_no_theme_top20_count: 8
- retained_count: 8
- retention_ratio: 100.00%
- interpretation: baseline top20 no-theme names retained at 100.00%.

## 3. Theme Concentration
- status: PASS
- max_theme: (none)
- max_share: 40.00%
- max_count: 8
- interpretation: the largest dominant theme share in overlay top20 is 40.00%.

## 4. Near-Top20 Entry Quality
- status: FAIL
- entry_count: 0
- explainable_count: 0
- explainable_ratio: 0.00%
- interpretation: explainable new entries account for 0.00%.

## 5. Theme Lift Effect
- status: WARN
- lifted_count: 0
- high_effective_count: 0
- high_effective_ratio: 0.00%
- high_effective_threshold: 0.0000
- interpretation: high theme-effective names among lifted stocks account for 0.00%.

## 6. Shadow Effect Diagnostics
- direct_uplift_count: 0
- direct_uplift_top20_count: 0
- indirect_rank_gain_count: 0
- large_negative_displacement_count: 0
- minimal_score_delta_threshold: 0.05
- large_negative_score_delta_threshold: -1.00
- interpretation: direct uplift means positive score delta with positive rank gain; indirect rank gain means rank gain with score delta near zero; large negative displacement tracks strong losers.

## 7. Explain Consistency
- sample_count: 20
- manual_review_count: 20
- interpretation: top overlay names are sampled for theme/explain consistency review.

## Review Pointers
- Check whether names with `(none)` dominant_theme still contain theme wording in explain_text.
- Check whether low-confidence new entries are being over-promoted.
- Check whether a single theme is dominating top20 beyond the intended cap.

## Output Files
- data\top20_churn_analysis.csv
- data\no_theme_retention.csv
- data\theme_concentration.csv
- data\theme_lift_analysis.csv
- data\new_entry_quality_report.csv
- data\theme_overlay_acceptance_mode_note.md

## Explain Sample
```json
[
  {
    "date":"2026-04-15",
    "code":"027360",
    "name":"아주IB투자",
    "overlay_rank":1,
    "dominant_theme":"(none)",
    "theme_confidence":0.0,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 83.3 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 37.6) | top_positive_factor=Primary prediction score (37.6) | top_negative_factor=Risk penalty (-7.2)\n핵심 driver: Primary prediction score (ret_score) contribution 37.6, score 98.8; Top-bucket probability score (prob_score) contribution 26.9, score 99.5; Tech flow score (tech_score) contribution 20.7, score 76.5\n리스크 요인: top_negative_factor=Risk penalty (-7.2); risk_penalty 18.0\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-15",
    "code":"007390",
    "name":"네이처셀",
    "overlay_rank":2,
    "dominant_theme":"바이오",
    "theme_confidence":0.4433077528,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 77.5 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 35.3) | top_positive_factor=Primary prediction score (35.3) | top_negative_factor=Risk penalty (-5.4)\n핵심 driver: Primary prediction score (ret_score) contribution 35.3, score 92.9; Top-bucket probability score (prob_score) contribution 25.3, score 93.7; Tech flow score (tech_score) contribution 21.6, score 79.9\n리스크 요인: top_negative_factor=Risk penalty (-5.4); risk_penalty 13.4\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-15",
    "code":"336370",
    "name":"솔루스첨단소재",
    "overlay_rank":3,
    "dominant_theme":"2차전지",
    "theme_confidence":0.413187708,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 76.4 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 35.5) | top_positive_factor=Primary prediction score (35.5) | top_negative_factor=Risk penalty (-7.2)\n핵심 driver: Primary prediction score (ret_score) contribution 35.5, score 93.3; Top-bucket probability score (prob_score) contribution 26.1, score 96.6; Tech flow score (tech_score) contribution 21.1, score 78.3\n리스크 요인: top_negative_factor=Risk penalty (-7.2); risk_penalty 18.0\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-15",
    "code":"001440",
    "name":"대한전선",
    "overlay_rank":4,
    "dominant_theme":"(none)",
    "theme_confidence":0.0,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 73.3 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 33.8) | top_positive_factor=Primary prediction score (33.8) | top_negative_factor=Risk penalty (-6.7)\n핵심 driver: Primary prediction score (ret_score) contribution 33.8, score 89.0; Top-bucket probability score (prob_score) contribution 23.3, score 86.4; Tech flow score (tech_score) contribution 21.4, score 79.3\n리스크 요인: top_negative_factor=Risk penalty (-6.7); risk_penalty 16.7\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-15",
    "code":"089030",
    "name":"테크윙",
    "overlay_rank":5,
    "dominant_theme":"반도체장비",
    "theme_confidence":0.6068666058,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 73.1 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 37.2) | top_positive_factor=Primary prediction score (37.2) | top_negative_factor=Risk penalty (-7.2)\n핵심 driver: Primary prediction score (ret_score) contribution 37.2, score 97.8; Top-bucket probability score (prob_score) contribution 22.5, score 83.5; Tech flow score (tech_score) contribution 19.7, score 73.0\n리스크 요인: top_negative_factor=Risk penalty (-7.2); risk_penalty 18.0\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-15",
    "code":"178320",
    "name":"서진시스템",
    "overlay_rank":6,
    "dominant_theme":"AI서버기판",
    "theme_confidence":0.6516618613,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 72.8 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 33.3) | top_positive_factor=Primary prediction score (33.3) | top_negative_factor=Risk penalty (-7.2)\n핵심 driver: Primary prediction score (ret_score) contribution 33.3, score 87.6; Top-bucket probability score (prob_score) contribution 24.5, score 90.8; Tech flow score (tech_score) contribution 20.5, score 75.8\n리스크 요인: top_negative_factor=Risk penalty (-7.2); risk_penalty 18.0\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-15",
    "code":"032640",
    "name":"LG유플러스",
    "overlay_rank":7,
    "dominant_theme":"Digital Connectivity",
    "theme_confidence":0.6926322993,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 72.6 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 29.8) | top_positive_factor=Primary prediction score (29.8) | top_negative_factor=Risk penalty (-3.0)\n핵심 driver: Primary prediction score (ret_score) contribution 29.8, score 78.3; Tech flow score (tech_score) contribution 21.7, score 80.2; Top-bucket probability score (prob_score) contribution 21.0, score 77.7\n리스크 요인: top_negative_factor=Risk penalty (-3.0); risk_penalty 7.4\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-15",
    "code":"127120",
    "name":"제이에스링크",
    "overlay_rank":8,
    "dominant_theme":"(none)",
    "theme_confidence":0.0,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 71.7 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 36.1) | top_positive_factor=Primary prediction score (36.1) | top_negative_factor=Risk penalty (-7.2)\n핵심 driver: Primary prediction score (ret_score) contribution 36.1, score 95.0; Top-bucket probability score (prob_score) contribution 23.6, score 87.4; Tech flow score (tech_score) contribution 18.9, score 70.2\n리스크 요인: top_negative_factor=Risk penalty (-7.2); risk_penalty 18.0\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-15",
    "code":"035900",
    "name":"JYP Ent.",
    "overlay_rank":9,
    "dominant_theme":"(none)",
    "theme_confidence":0.0,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 71.2 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 33.2) | top_positive_factor=Primary prediction score (33.2) | top_negative_factor=Risk penalty (-3.8)\n핵심 driver: Primary prediction score (ret_score) contribution 33.2, score 87.4; Top-bucket probability score (prob_score) contribution 26.3, score 97.6; Tech flow score (tech_score) contribution 8.7, score 32.3\n리스크 요인: top_negative_factor=Risk penalty (-3.8); risk_penalty 9.6\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-15",
    "code":"060370",
    "name":"LS마린솔루션",
    "overlay_rank":10,
    "dominant_theme":"전력설비",
    "theme_confidence":0.6260607664,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 71.2 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 33.6) | top_positive_factor=Primary prediction score (33.6) | top_negative_factor=Risk penalty (-6.3)\n핵심 driver: Primary prediction score (ret_score) contribution 33.6, score 88.3; Top-bucket probability score (prob_score) contribution 24.4, score 90.3; Tech flow score (tech_score) contribution 16.7, score 62.0\n리스크 요인: top_negative_factor=Risk penalty (-6.3); risk_penalty 15.7\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-15",
    "code":"214150",
    "name":"클래시스",
    "overlay_rank":11,
    "dominant_theme":"바이오",
    "theme_confidence":0.3483077528,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 71.1 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 27.3) | top_positive_factor=Primary prediction score (27.3) | top_negative_factor=Risk penalty (-4.6)\n핵심 driver: Primary prediction score (ret_score) contribution 27.3, score 71.8; Top-bucket probability score (prob_score) contribution 22.7, score 84.0; Tech flow score (tech_score) contribution 18.1, score 67.1\n리스크 요인: top_negative_factor=Risk penalty (-4.6); risk_penalty 11.6\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-15",
    "code":"281740",
    "name":"레이크머티리얼즈",
    "overlay_rank":12,
    "dominant_theme":"2차전지",
    "theme_confidence":0.380687708,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 71.1 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 33.3) | top_positive_factor=Primary prediction score (33.3) | top_negative_factor=Risk penalty (-7.2)\n핵심 driver: Primary prediction score (ret_score) contribution 33.3, score 87.5; Top-bucket probability score (prob_score) contribution 24.9, score 92.2; Tech flow score (tech_score) contribution 18.5, score 68.6\n리스크 요인: top_negative_factor=Risk penalty (-7.2); risk_penalty 18.0\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-15",
    "code":"005940",
    "name":"NH투자증권",
    "overlay_rank":13,
    "dominant_theme":"Brokerage Markets",
    "theme_confidence":0.6787996106,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 70.5 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 33.4) | top_positive_factor=Primary prediction score (33.4) | top_negative_factor=Risk penalty (-7.2)\n핵심 driver: Primary prediction score (ret_score) contribution 33.4, score 87.9; Top-bucket probability score (prob_score) contribution 25.0, score 92.7; Tech flow score (tech_score) contribution 18.1, score 67.0\n리스크 요인: top_negative_factor=Risk penalty (-7.2); risk_penalty 18.0\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-15",
    "code":"017670",
    "name":"SK텔레콤",
    "overlay_rank":14,
    "dominant_theme":"Digital Connectivity",
    "theme_confidence":0.7026322993,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 69.8 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 32.3) | top_positive_factor=Primary prediction score (32.3) | top_negative_factor=Risk penalty (-7.2)\n핵심 driver: Primary prediction score (ret_score) contribution 32.3, score 84.9; Tech flow score (tech_score) contribution 22.8, score 84.5; Top-bucket probability score (prob_score) contribution 20.4, score 75.7\n리스크 요인: top_negative_factor=Risk penalty (-7.2); risk_penalty 18.0\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-15",
    "code":"278470",
    "name":"에이피알",
    "overlay_rank":15,
    "dominant_theme":"(none)",
    "theme_confidence":0.0,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 69.3 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 32.7) | top_positive_factor=Primary prediction score (32.7) | top_negative_factor=Risk penalty (-5.7)\n핵심 driver: Primary prediction score (ret_score) contribution 32.7, score 86.0; Tech flow score (tech_score) contribution 21.2, score 78.4; Top-bucket probability score (prob_score) contribution 17.0, score 63.1\n리스크 요인: top_negative_factor=Risk penalty (-5.7); risk_penalty 14.1\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-15",
    "code":"397030",
    "name":"에이프릴바이오",
    "overlay_rank":16,
    "dominant_theme":"(none)",
    "theme_confidence":0.0,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 69.1 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 36.0) | top_positive_factor=Primary prediction score (36.0) | top_negative_factor=Risk penalty (-7.2)\n핵심 driver: Primary prediction score (ret_score) contribution 36.0, score 94.6; Top-bucket probability score (prob_score) contribution 26.0, score 96.1; Tech flow score (tech_score) contribution 13.6, score 50.6\n리스크 요인: top_negative_factor=Risk penalty (-7.2); risk_penalty 18.0\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-15",
    "code":"096530",
    "name":"씨젠",
    "overlay_rank":17,
    "dominant_theme":"바이오",
    "theme_confidence":0.4308077528,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 68.5 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 30.6) | top_positive_factor=Primary prediction score (30.6) | top_negative_factor=Risk penalty (-5.4)\n핵심 driver: Primary prediction score (ret_score) contribution 30.6, score 80.6; Top-bucket probability score (prob_score) contribution 24.6, score 91.3; Tech flow score (tech_score) contribution 16.0, score 59.4\n리스크 요인: top_negative_factor=Risk penalty (-5.4); risk_penalty 13.6\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-15",
    "code":"417200",
    "name":"LS머트리얼즈",
    "overlay_rank":18,
    "dominant_theme":"(none)",
    "theme_confidence":0.0,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 68.2 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 34.0) | top_positive_factor=Primary prediction score (34.0) | top_negative_factor=Risk penalty (-7.2)\n핵심 driver: Primary prediction score (ret_score) contribution 34.0, score 89.4; Top-bucket probability score (prob_score) contribution 21.8, score 80.6; Tech flow score (tech_score) contribution 17.8, score 65.8\n리스크 요인: top_negative_factor=Risk penalty (-7.2); risk_penalty 18.0\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-15",
    "code":"085660",
    "name":"차바이오텍",
    "overlay_rank":19,
    "dominant_theme":"바이오",
    "theme_confidence":0.4683077528,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 68.0 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 37.6) | top_positive_factor=Primary prediction score (37.6) | top_negative_factor=Risk penalty (-6.0)\n핵심 driver: Primary prediction score (ret_score) contribution 37.6, score 99.0; Top-bucket probability score (prob_score) contribution 26.5, score 98.1; Tech flow score (tech_score) contribution 9.2, score 34.1\n리스크 요인: top_negative_factor=Risk penalty (-6.0); risk_penalty 15.1\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  },
  {
    "date":"2026-04-15",
    "code":"160190",
    "name":"하이젠알앤엠",
    "overlay_rank":20,
    "dominant_theme":"(none)",
    "theme_confidence":0.0,
    "has_theme_explain":false,
    "manual_review_flag":true,
    "review_point":"Check theme-to-explain linkage manually.",
    "explain_text":"요약: live_score 67.9 | live_score_source=final_score | regime=bull | dominant_driver=ret (Primary prediction score 37.2) | top_positive_factor=Primary prediction score (37.2) | top_negative_factor=Risk penalty (-6.2)\n핵심 driver: Primary prediction score (ret_score) contribution 37.2, score 97.9; Top-bucket probability score (prob_score) contribution 25.2, score 93.2; Tech flow score (tech_score) contribution 11.2, score 41.5\n리스크 요인: top_negative_factor=Risk penalty (-6.2); risk_penalty 15.5\n운영 상태: theme_overlay: disabled (operational config); confidence: 모델 메타 점수 (calibration 미완), score=NA, label=Experimental, live_score 비반영, research\/reference 용도"
  }
]
```
