# Theme Overlay Mode Resolution

## Mode Definitions
- off: theme calculation and score reflection are both disabled.
- shadow: theme calculation is allowed, but final_score_v2/final_score_v3 do not reflect theme.
- operational: theme calculation and score reflection are both enabled.

## Environment Rules
- ENABLE_THEME_OVERLAY != 1 -> resolved mode is off
- THEME_OVERLAY_MODE=shadow -> resolved mode is shadow
- THEME_OVERLAY_MODE=operational -> resolved mode is operational
- Any other THEME_OVERLAY_MODE value -> invalid_mode fallback to off

## Current Resolution
- requested_execution_mode: false
- resolved_execution_mode: off
- fallback_applied: True
- fallback_reason: disabled_by_flag
- current_execution_mode: off
- overlay_gate_result: disabled
- overlay_disable_reason: disabled_by_flag
