# Theme Overlay Gate Debug

- overlay requested: false
- requested mode: false
- current mode: off
- requested execution mode: false
- resolved execution mode: off
- fallback applied: true
- fallback reason: disabled_by_flag
- validation enabled: false
- final gate result: disabled
- disable reason: disabled_by_flag
- theme weight source priority: best_weight_by_regime, best_weight_by_regime_global, best_weight_global, fallback_default
- theme weight config available: {'best_weight_by_regime': True, 'best_weight_global': True}

## Raw Values
- enable_theme_overlay_raw: 0
- enable_theme_validation_raw: 0
- theme_weight_config_paths: {'best_weight_by_regime': 'data\\experiments\\theme_weight\\best_weight_by_regime.json', 'best_weight_global': 'data\\experiments\\theme_weight\\best_weight.json'}
