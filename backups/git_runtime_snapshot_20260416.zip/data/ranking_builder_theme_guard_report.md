# Ranking Builder Theme Guard Report

## Gate Status
- overlay_enabled_env: False
- mode: off
- operational_gate: False
- applied: False
- disable_reason: disabled_by_flag

## Coverage Stats
- coverage_ratio_guard: 0.4709
- coverage_ratio_live_latest: 0.4709
- coverage_threshold: 0.3500
- matched_rows: 97
- base_rows: 206
- theme_row_count: 116

## Date Check
- ranking_latest_date: 2026-04-15
- theme_latest_date: 2026-04-15
- available_theme_dates: ['2026-04-15']
- date_mismatch_test: DISABLE

## Disable Case Tests
- mode_mismatch: hard disable implemented
- stale_date: hard disable implemented
- low_coverage: hard disable implemented
- empty_data: hard disable implemented

## Runtime Notes
- source: csv
- final_score baseline is unchanged; theme guard only controls overlay inputs used by final_score_v2/final_score_v3.
- explain_text includes theme text only when an active dominant_theme exists.
