# Ranking Snapshot Inventory

- total snapshot count: 21
- matured snapshot count 20d: 2
- matured snapshot count 60d: 0
- matured snapshot count 90d: 0
- oldest snapshot date: 2026-03-17
- latest snapshot date: 2026-04-16
- confidence calibration readiness 60d: WAIT
- note: Keep accumulating dated ranking snapshots until at least one 60d-matured snapshot exists.
