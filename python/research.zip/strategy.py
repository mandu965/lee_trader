# python/research/strategy.py
import pandas as pd
try:
    from .config import BacktestConfig
except ImportError:
    from config import BacktestConfig


def select_top_n(
    df: pd.DataFrame,
    config: BacktestConfig,
) -> pd.DataFrame:
    """
    date, model_version 기준으로 config.score_column 순서로 top_n 선택.
    """
    score_col = config.score_column
    top_n = config.top_n

    picks = (
        df
        .sort_values(["date", "model_version", score_col],
                     ascending=[True, True, False])
        .groupby(["date", "model_version"])
        .head(top_n)
        .reset_index(drop=True)
    )
    return picks


def evaluate_strategy(
    picks: pd.DataFrame,
    config: BacktestConfig,
    benchmark: pd.DataFrame | None = None,
) -> pd.DataFrame:
    """
    picks: select_top_n 결과 + realized_return 포함
    return: date, model_version 별 포트폴리오 수익률 집계
    """
    if "realized_return" not in picks.columns:
        raise KeyError("picks must contain realized_return")

    port = (
        picks
        .groupby(["date", "model_version"], as_index=False)
        .agg(
            portfolio_return=("realized_return", "mean"),
            # 필요하면 종목별 MDD까지 확장 예정
        )
        .sort_values(["date", "model_version"])
        .reset_index(drop=True)
    )

    # 누적 수익률 (단순 곱)
    port["cum_return"] = (
        port.groupby("model_version")["portfolio_return"]
        .apply(lambda s: (1 + s).cumprod() - 1)
        .reset_index(level=0, drop=True)
    )

    # benchmark 대비 초과수익 (date, return 컬럼 기대)
    if benchmark is not None and not benchmark.empty:
        bmk = benchmark.copy()
        bmk["date"] = pd.to_datetime(bmk["date"]).dt.date
        if "return" not in bmk.columns and "close" in bmk.columns:
            bmk = bmk.sort_values("date")
            bmk["return"] = bmk["close"].pct_change()
        bmk = bmk.dropna(subset=["return"])
        bmk = bmk[["date", "return"]].rename(columns={"return": "benchmark_return"})
        port = port.merge(bmk, on="date", how="left")
        port["excess_return"] = port["portfolio_return"] - port["benchmark_return"]

    return port
