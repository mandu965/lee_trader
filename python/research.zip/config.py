# python/research/config.py
from dataclasses import dataclass, field
from datetime import date
from typing import List, Optional, Literal


@dataclass
class ScoreWeights:
    w_ret: float = 1.0
    w_prob: float = 1.0
    w_qual: float = 1.0
    w_tech: float = 1.0
    w_risk: float = 1.0
    w_market: float = 0.0  # 필요시 확장


@dataclass
class BacktestConfig:
    # 기간 / 모델
    start_date: date
    end_date: date
    model_versions: List[str]

    # 전략 파라미터
    horizon_days: int = 60
    top_n: int = 20
    score_column: str = "final_score_custom"  # 또는 final_score_original

    # 점수 가중치 (튜닝용)
    weights: ScoreWeights = field(default_factory=ScoreWeights)

    # 데이터 소스
    prediction_source: Literal["db", "csv"] = "csv"
    price_source: Literal["db", "csv"] = "csv"
    predictions_csv: str = "data/predictions.csv"
    prices_csv: str = "data/prices_daily_adjusted.csv"

    # 벤치마크
    benchmark_code: Optional[str] = None
    benchmark_csv: Optional[str] = None

    # 출력
    output_dir: str = "outputs/backtest"
