# python/research/data_loader.py
import os
import pandas as pd
from sqlalchemy import text
from .config import BacktestConfig
try:
    from ..db import get_engine  # when imported as package
except ImportError:
    from db import get_engine    # fallback when running standalone


def load_predictions(config: BacktestConfig) -> pd.DataFrame:
    """
    Expected columns (CSV mode):
      date, code, model_version,
      pred_return_60d, pred_mdd_60d, prob_top20_60d,
      ret_score, prob_score, qual_score, tech_score,
      risk_penalty, final_score (optional)
    """
    if config.prediction_source == "db":
        eng = get_engine()
        sql = text(
            """
            SELECT
              date,
              code,
              pred_return_60d,
              pred_return_90d,
              pred_mdd_60d,
              pred_mdd_90d,
              prob_top20_60d,
              prob_top20_90d,
              ret_score,
              prob_score,
              qual_score,
              tech_score,
              risk_penalty,
              final_score
            FROM daily_ranking
            WHERE date BETWEEN :start AND :end
            """
        )
        df = pd.read_sql(sql, eng, params={"start": config.start_date, "end": config.end_date})
        # daily_ranking에 model_version이 없다면 기본값 사용
        default_mv = config.model_versions[0] if config.model_versions else "default"
        df["model_version"] = default_mv
    else:
        path = config.predictions_csv
        if not os.path.exists(path):
            raise FileNotFoundError(f"predictions_csv not found: {path}")

        df = pd.read_csv(path)

        if "model_version" not in df.columns:
            default_mv = config.model_versions[0] if config.model_versions else "default"
            df["model_version"] = default_mv

    df["date"] = pd.to_datetime(df["date"]).dt.date
    df["code"] = df["code"].astype(str)

    df = df[
        (df["date"] >= config.start_date)
        & (df["date"] <= config.end_date)
        & (df["model_version"].isin(config.model_versions))
    ].copy()

    if "ret_score" not in df.columns and "pred_return_60d" in df.columns:
        df["ret_score"] = df["pred_return_60d"] * 100.0
    if "prob_score" not in df.columns and "prob_top20_60d" in df.columns:
        df["prob_score"] = df["prob_top20_60d"] * 100.0
    for col in ["qual_score", "tech_score", "risk_penalty"]:
        if col not in df.columns:
            df[col] = 0.0

    return df


def load_prices(config: BacktestConfig) -> pd.DataFrame:
    """
    Expected columns:
      date, code, close (adj_close accepted and renamed)
    """
    if config.price_source == "db":
        eng = get_engine()
        sql = text(
            """
            SELECT
              date,
              code,
              COALESCE(adj_close, close) AS close
            FROM fact_price_daily
            WHERE date BETWEEN :start AND :end
            """
        )
        prices = pd.read_sql(sql, eng, params={"start": config.start_date, "end": config.end_date})
    else:
        path = config.prices_csv
        if not os.path.exists(path):
            raise FileNotFoundError(f"prices_csv not found: {path}")

        prices = pd.read_csv(path)
        if "close" not in prices.columns:
            if "adj_close" in prices.columns:
                prices = prices.rename(columns={"adj_close": "close"})
            else:
                raise ValueError("prices_csv must contain 'close' or 'adj_close'")

    prices["date"] = pd.to_datetime(prices["date"]).dt.date
    prices["code"] = prices["code"].astype(str)
    horizon_buf = getattr(config, "horizon_days", 0) or 0
    end_with_horizon = pd.to_datetime(config.end_date) + pd.Timedelta(days=horizon_buf)
    prices = prices[
        (prices["date"] >= config.start_date)
        & (prices["date"] <= end_with_horizon.date())
    ].copy()

    return prices[["date", "code", "close"]].copy()


def load_benchmark(config: BacktestConfig) -> pd.DataFrame:
    """
    columns:
      date, close, return (return optional; derived if missing)
    """
    if not config.benchmark_code and not config.benchmark_csv:
        return pd.DataFrame()

    if config.benchmark_csv and os.path.exists(config.benchmark_csv):
        bench = pd.read_csv(config.benchmark_csv)
        bench["date"] = pd.to_datetime(bench["date"]).dt.date
        if "close" not in bench.columns:
            raise ValueError("benchmark_csv must contain 'close'")
        bench = bench.sort_values("date")
        if "return" not in bench.columns:
            bench["return"] = bench["close"].pct_change()
        bench = bench.dropna(subset=["return"])
        return bench[["date", "close", "return"]].copy()

    # DB에서 벤치마크 코드가 fact_price_daily에 있는 경우 로드 시도
    if config.benchmark_code:
        try:
            eng = get_engine()
            sql = text(
                """
                SELECT date, COALESCE(adj_close, close) AS close
                FROM fact_price_daily
                WHERE code = :code AND date BETWEEN :start AND :end
                ORDER BY date
                """
            )
            bench = pd.read_sql(
                sql,
                eng,
                params={"code": config.benchmark_code, "start": config.start_date, "end": config.end_date},
            )
            if not bench.empty:
                bench["date"] = pd.to_datetime(bench["date"]).dt.date
                bench["return"] = bench["close"].pct_change()
                bench = bench.dropna(subset=["return"])
                return bench[["date", "close", "return"]].copy()
        except Exception:
            # optional fallback; silence to allow CSV-only workflows
            pass

    # TODO: hook into benchmark_etf_comparison.py or DB when available
    return pd.DataFrame()
